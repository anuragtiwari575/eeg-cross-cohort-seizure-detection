# Dataset shift costs less than patient shift in automated scalp EEG seizure detection

**Anurag Tiwari**
Department of Computer Science and Engineering, South Asian University,
Maidan Garhi, New Delhi 110068, India
anuragtiwari@sau.int

---

## 1. Introduction

Automated seizure detection from scalp EEG has been reported at near-ceiling performance for more than a decade. On the CHB-MIT Scalp EEG Database (Shoeb, 2009) accuracies above 98% are routine, and several recent systems report figures above 99% together with false-prediction rates below 0.006 per hour (Scientific Reports, 2025). Clinical adoption has not followed. The discrepancy is usually attributed to distribution shift: a detector developed at one centre, on one acquisition system, in one patient population, is expected to fail at another. That expectation has motivated a substantial literature on domain adaptation for EEG, in which the target domain is variously defined as an unseen subject or an unseen dataset (Jemal et al., 2024).

The expectation is plausible but has not been measured. Cross-subject and cross-dataset generalization are treated as related but distinct problems, and the latter is generally presented as the harder of the two, yet the two are rarely evaluated side by side on identical windows, under identical splits, with identical models. Without that comparison it cannot be established whether a method that improves cross-dataset transfer is addressing dataset shift specifically, or is addressing inter-subject variability that is equally present within a single cohort. The distinction matters practically: if the residual error after aligning two datasets is inter-subject rather than inter-dataset, then the alignment is operating on the wrong axis, and the reported improvement would also have been obtained by pooling more subjects.

A second difficulty is that reported figures are not comparable between studies. A recent survey of cross-subject EEG decoding identifies the absence of standardized benchmarking pipelines as a principal obstacle, noting that differences in artifact rejection thresholds, spectral filtering ranges, subject exclusion criteria, subject-split strategy and validation protocol substantially alter task difficulty, so that reported accuracies reflect the experimental pipeline as much as the intrinsic merit of the method (Cross-Subject Survey, 2026). In seizure detection this is acute, because the positive class is rare: interictal activity dominates continuous recording by two to three orders of magnitude, and the near-universal practice of rebalancing before evaluation—by synthetic minority oversampling, by overlapping-window augmentation, or by majority undersampling—changes the operating conditions of the reported metric. Saha et al. (2024) examined evaluation practice on CHB-MIT specifically and observed that many studies do not evaluate on the full recording, and that partial-data experiments yield high apparent performance that does not survive the imbalanced continuous setting.

This is an instance of a more general problem, one we have previously characterised in a different modality. In interictal intracranial EEG, average precision—the metric ordinarily used to report localization performance—is determined in part by the positive-class rate, which is itself set by cohort composition; a model given composition alone, with no recording, predicted reported average precision with cross-validated R² up to 0.70 (Tiwari, 2026). The mechanism transfers directly. Any metric whose chance level depends on prevalence will move when prevalence moves, and in seizure detection prevalence is a design choice rather than a property of the disease. The area under the receiver operating characteristic curve is prevalence-invariant and so does not exhibit the effect, but it is for that reason unable to reveal it, and it weights all parts of the ranking equally in a task where only the top of the ranking is clinically actionable (Saito and Rehmsmeier, 2015).

We therefore ran a controlled comparison. Two public scalp EEG cohorts were used that differ in patient age, acquisition hardware, sampling rate, electrode montage and mains frequency, and that consequently constitute a genuine dataset-level shift rather than a nominal one. A set of published architectures spanning three orders of magnitude in parameter count, together with two handcrafted spectral feature families, were evaluated under a single fully specified protocol with three nested settings: within-patient, cross-patient within a cohort, and cross-cohort. Every model saw the same windows, the same splits and the same preprocessing, so that differences between settings are attributable to the setting rather than to the pipeline.

We asked three questions. How large is the additional cost of crossing a dataset boundary, relative to the cost of crossing a patient boundary? Does that comparison depend on the choice of architecture, or on whether the representation is learned or hand-designed? And how much of the spread in reported seizure-detection performance is attributable to evaluation prevalence rather than to method?

We do not propose a new architecture. The finding of this study is that architecture is not where the limiting factor lies.

---

## 2. Related work

### 2.1 Performance and its interpretation on CHB-MIT

CHB-MIT (Shoeb, 2009) has been the dominant benchmark for scalp EEG seizure detection for over a decade, and reported performance has risen steadily. Recent work using classical feature engineering with explicit leakage control reports an area under the curve of 0.927 from a compact fifteen-feature set under strictly patient-independent nested cross-validation, with feature selection and spatial filtering performed within training folds only (Discover Applied Sciences, 2026). Deep architectures routinely report higher figures. The gap between these two families of results is not straightforwardly attributable to representational capacity, because the evaluation protocols differ in ways that affect the achievable value of the metric.

The reliability of the higher figures has been questioned from within the field. Saha et al. (2024) note that studies frequently evaluate on a subset rather than the full continuous recording. Independently, the same concern appears in the general EEG decoding literature (Cross-Subject Survey, 2026). Our contribution is to quantify the size of the effect for this task rather than to restate its existence.

### 2.2 Cross-subject and cross-dataset transfer

Cross-patient detectors have long been recognised as substantially harder than patient-specific ones, since seizure morphology, localization and duration vary markedly between individuals. Domain adaptation has been the dominant response. Jemal et al. (2024) evaluated three domain adaptation methods on CHB-MIT and Siena and reported accuracy improvements of 10.3% and 7.4% respectively. More recent architectures report cross-patient area under the curve on Siena in the region of 0.70 without any target-domain adaptation, exceeding the best domain-adapted figure of 0.61 reported by Jemal et al. on the same data (CG-MambaNet, 2026; CLSP-REQA, 2026). That a method without adaptation should exceed one with it is itself evidence that the two figures are not measuring the same quantity under the same conditions.

Cross-dataset evaluation between CHB-MIT and Siena has been performed in both directions and in a pooled configuration (Scientific Reports, 2025), with F1 exceeding 95% reported for pure cross-dataset transfer. That evaluation follows a pipeline in which the minority class is expanded by synthetic minority oversampling and by sliding windows with 80% overlap, and the majority class is then undersampled to match. Overlapping-window augmentation at this rate produces near-duplicate windows within a single seizure episode, and rebalancing prior to evaluation fixes the prevalence at which the metric is computed. Neither choice is incorrect in itself, and both are declared; the difficulty is that a figure obtained under those conditions and a figure obtained on continuous recording are not comparable, and nothing in the reported metrics indicates by how much they differ.

### 2.3 Standardized benchmarking

The need for standardized evaluation has been recognised recently and general-purpose EEG benchmarks have begun to appear, covering many datasets and, principally, foundation models under common interfaces and fixed splits (OmniEEG-Bench, 2026; EEG-Bench, 2026). These efforts address breadth. The present study is complementary in addressing depth: rather than establishing a common interface across many tasks, we hold one clinical task fixed and vary the generalization setting and the evaluation prevalence, so that the contribution of protocol to reported performance can be isolated from the contribution of method.

A directly analogous comparison has been reported outside seizure detection. In consumer-grade EEG emotion recognition, a systematic comparison of EEGNet against traditional feature engineering with cross-dataset validation found that handcrafted features outperformed end-to-end learning in that low-channel, high-noise regime (Consumer EEG, 2026). Our result runs in the opposite direction, which is informative rather than contradictory: the advantage of learned representations appears to be regime-dependent, and a comparison of the two regimes constrains when either should be preferred.

### 2.4 Null models and the interpretation of a reported figure

The principle we build on is established. Conrad et al. (2022) constructed a spatial null that predicts which intracranial electrodes lie in the seizure onset zone from electrode placement alone, with no EEG data, and found that it classified electrodes at an area under the curve of 0.70, and that adding functional connectivity did not significantly improve on it; they argued that a feature should be required to outperform such a null before being called a biomarker. We have previously extended that argument from within-participant electrode placement to between-participant cohort composition, and from the classifier to the metric in which its performance is reported (Tiwari, 2026).

The present study extends it once more, in a third direction: from a single dataset to the comparison between datasets. The question is not whether a detector exceeds chance, but whether the difference between two reported figures reflects a difference in method or a difference in the conditions under which each was measured. We address this with two negative controls—label permutation, and a test of whether recordings that contain seizures are distinguishable from recordings that do not, using only their non-seizure windows—and with an explicit sweep of evaluation prevalence across the range used in the literature.

### 2.5 Position of this work

Relative to the above, this study (i) measures cross-patient and cross-dataset transfer under one protocol rather than treating them as separate problems, (ii) evaluates at native prevalence rather than after rebalancing, and (iii) reports the protocol dependence of the metrics themselves. It proposes no new detector.

---

## Notes on this draft

**Citation keys are placeholders.** Every reference above was identified during literature search and must be verified against the published record before submission; several are arXiv preprints that may since have appeared in journals. The two exceptions are Shoeb (2009), Saito and Rehmsmeier (2015) and Conrad et al. (2022), which appear in your own reference list and can be carried across.

**On §1, paragraph 4 and §2.4.** These deliberately connect this paper to your iEEG composition manuscript. Two papers making the same methodological argument in two modalities is a research programme rather than two isolated results, and reviewers of the second will read the first as evidence that the concern is general rather than incidental. If the iEEG paper is still under review, cite it as a preprint or as "submitted"; if it is accepted before this one, the link becomes stronger.

**On what is deliberately absent.** There is no separate statement of contributions as a numbered list — your iEEG manuscript does not use one, and the three-question formulation at the end of §1 serves the same purpose in the same style. If the target journal expects a contributions list, it can be added as a short paragraph.

**On the claim in the title.** It is stated as a finding, which is only defensible once the architecture sweep is complete. Until then keep a neutral working title.
