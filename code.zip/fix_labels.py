"""
=============================================================================
FIX THE SIENA ANNOTATIONS
=============================================================================
    python -u fix_labels.py diagnose      print what the files contain
    python -u fix_labels.py rebuild       write corrected annotations

Two defects, both in our parsing rather than in the database.

PN01

    The information file lists two seizures. Our parser finds none, so all
    12 139 windows of that subject, 13.5 hours, are labelled negative. A
    detector that fires correctly there is penalised for it, and the
    principal cross-cohort direction tests on Siena, so the defect lands on
    the quantity the paper interprets.

PN00-3

    The annotation reads 18.28.29 to 19.29.29, a seizure of 3660 s in a
    recording of 2509 s. Our parser discards annotations longer than an
    hour, so the seizure is absent. The end time is transcriptionally wrong
    and the start is not; read as 18.29.29 it is a 60 s seizure the
    recording does contain.

WHY DIAGNOSE FIRST

    We do not know why PN01 fails. The subject has one EDF of 13.5 hours
    where most subjects have several shorter ones, so the annotation file
    may reference a file name our parser does not match, or may use a
    different field layout. Guessing at a fix and applying it silently is
    how the original defect arose. The diagnose mode prints the raw file
    and what each candidate rule would extract, so the fix is chosen from
    evidence.

WHAT REBUILD WRITES

    D:\\siena_fixed\\annotations.csv, one row per seizure with subject,
    recording, start and end in seconds from the start of that recording,
    and a note saying how each was obtained. Nothing else is touched: the
    feature extraction reads this file, so the rest of the pipeline reruns
    unchanged.
=============================================================================
"""
from pathlib import Path
import sys, re, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd

SIENA = Path(r"D:\CPU-Intel 7\C_Drive\archive\siena-scalp-eeg-database-1.0.0")
OUT = Path(r"D:\siena_fixed"); OUT.mkdir(parents=True, exist_ok=True)
MAX_SZ = 3600.0

def log(m): print(m, flush=True)


def hhmmss(s):
    """Seconds from an HH.MM.SS or HH:MM:SS token."""
    p = re.split(r"[.:]", s.strip())
    if len(p) != 3:
        return None
    try:
        h, m, sec = (int(x) for x in p)
    except ValueError:
        return None
    return h * 3600 + m * 60 + sec


def edf_start(path):
    import mne
    r = mne.io.read_raw_edf(path, preload=False, verbose="ERROR")
    d = r.info.get("meas_date")
    n = r.n_times / r.info["sfreq"]
    del r
    if d is None:
        return None, n
    return d.hour * 3600 + d.minute * 60 + d.second, n


# ================================================================ diagnose
def diagnose():
    log("=" * 70)
    log("WHAT THE ANNOTATION FILES CONTAIN")
    log("=" * 70)
    for subj in ("PN01", "PN00", "PN11"):
        d = SIENA / subj
        if not d.exists():
            log("\n%s: directory not found" % subj); continue
        log("\n" + "-" * 70)
        log("%s" % subj)
        log("-" * 70)
        log("  EDF files: %s" % [f.name for f in sorted(d.glob("*.edf"))])
        txts = sorted(d.glob("*.txt"))
        log("  text files: %s" % [f.name for f in txts])
        for f in txts:
            raw = f.read_text(errors="ignore")
            log("\n  ---- %s (%d bytes) ----" % (f.name, len(raw)))
            for line in raw.splitlines():
                if line.strip():
                    log("    | %s" % line.rstrip())
            log("  ---- what each rule finds ----")
            for name, pat in (
                ("Seizure start time", r"Seizure start time:\s*([\d.:]+)"),
                ("Seizure end time",   r"Seizure end time:\s*([\d.:]+)"),
                ("Registration start", r"Registration start time:\s*([\d.:]+)"),
                ("Registration end",   r"Registration end time:\s*([\d.:]+)"),
                ("File name",          r"File name:\s*(\S+)"),
                ("any HH.MM.SS",       r"\b(\d{1,2}[.:]\d{2}[.:]\d{2})\b"),
            ):
                hits = re.findall(pat, raw)
                log("    %-20s %s" % (name, hits if hits else "nothing"))

    info = SIENA / "subject_info.csv"
    if info.exists():
        si = pd.read_csv(info)
        col = [c for c in si.columns if "seizure" in c.lower() and "number" in c.lower()]
        if col:
            log("\n" + "=" * 70)
            log("subject_info.csv says:")
            for _, r in si.iterrows():
                log("  %-6s %d seizures" % (str(r.iloc[0]).strip(), r[col[0]]))

    log("\nRead the PN01 block above and see which field its file uses. If the")
    log("layout differs from the others, the rule in rebuild() needs the extra")
    log("case; if the file is simply absent, that is the finding and the two")
    log("seizures cannot be recovered from this database copy.")


# ================================================================ rebuild
def match_recording(declared, edfs, subj):
    """Map the declared file name onto an actual recording.

    Four of the fourteen annotation files name a file that does not exist.
    PN01 says PN01.edf where the recording is PN01-1.edf. PN11 says
    PN11-.edf where it is PN11-1.edf. PN06 writes the subject as PNO6, with
    a letter O in place of the zero, in three of its five entries. Exact
    matching drops all of these silently, which is how PN01's two seizures
    and three of PN06's five came to be missing from the labels.

    The rules below are deliberately narrow: strip the extension, normalise
    the letter O to zero inside the subject code, drop a trailing hyphen,
    and accept a unique prefix match. A looser rule would risk attaching a
    seizure to the wrong recording, which is worse than losing it."""
    if declared:
        c = declared.replace(".edf", "").replace(".EDF", "").upper()
        # PNO6 -> PN06: the letter O appears only as a mistyped zero here
        c = re.sub(r"^PN[O0](\d)", lambda m: "PN0" + m.group(1), c)
        c = re.sub(r"^PN([O0])", "PN0", c)
        c = c.rstrip("-")
        if c in edfs:
            return c
        same = [k for k in edfs if k == c or k.startswith(c + "-")]
        if len(same) == 1:
            return same[0]
    if len(edfs) == 1:
        return list(edfs)[0]
    return None


def rebuild():
    log("=" * 70)
    log("REBUILDING THE SIENA ANNOTATIONS")
    log("=" * 70)
    log("Three parsing defects are corrected here:")
    log("  PN01 writes 'Start time' where the others write 'Seizure start")
    log("    time', so our regex found nothing and both its seizures were lost")
    log("  PN01, PN11 and PN06 name files that do not exist: PN01.edf,")
    log("    PN11-.edf, and PNO6-n.edf with a letter O for the zero")
    log("  PN00-3 gives an end time an hour after the recording ends\n")

    rows, notes = [], []
    for d in sorted(p for p in SIENA.iterdir() if p.is_dir()):
        subj = d.name
        edfs = {f.stem.upper(): f for f in d.glob("*.edf")}
        if not edfs:
            continue
        starts = {}
        for k, f in edfs.items():
            s, n = edf_start(f)
            starts[k] = (s, n)

        txts = sorted(d.glob("*.txt"))
        if not txts:
            notes.append("%s: no annotation file" % subj); continue
        raw = "\n".join(f.read_text(errors="ignore") for f in txts)

        # file-level fields, used when a block does not carry its own
        top_file = re.search(r"File name:\s*(\S+)", raw)
        top_reg = re.search(r"Registration start time:\s*([\d.:]+)", raw)

        blocks = re.split(r"(?=Seizure n)", raw)
        blocks = [b for b in blocks if re.search(r"(?:Seizure )?[Ss]tart time", b)]
        if not blocks:
            notes.append("%s: no seizure blocks" % subj); continue

        for b in blocks:
            # PN01 omits the word "Seizure" from its time fields
            st = (re.search(r"Seizure start time:\s*([\d.:]+)", b) or
                  re.search(r"(?<!Registration )\bStart time:\s*([\d.:]+)", b))
            en = (re.search(r"Seizure end time:\s*([\d.:]+)", b) or
                  re.search(r"(?<!Registration )\bEnd time:\s*([\d.:]+)", b))
            if not (st and en):
                continue
            t0, t1 = hhmmss(st.group(1)), hhmmss(en.group(1))
            if t0 is None or t1 is None:
                notes.append("%s: unparsable times %s %s"
                             % (subj, st.group(1), en.group(1)))
                continue

            fn = re.search(r"File name:\s*(\S+)", b) or top_file
            key = match_recording(fn.group(1) if fn else None, edfs, subj)
            if key is None:
                notes.append("%s: cannot place a seizure at %s" % (subj, st.group(1)))
                continue

            reg = re.search(r"Registration start time:\s*([\d.:]+)", b) or top_reg
            s0, dur = starts[key]
            ref = hhmmss(reg.group(1)) if reg else s0
            if ref is None:
                ref = s0
            if ref is None:
                notes.append("%s/%s: no reference time" % (subj, key)); continue

            a = (t0 - ref) % 86400
            bsec = (t1 - ref) % 86400
            note = "as annotated"

            if bsec <= a or (bsec - a) > MAX_SZ:
                # PN00-3: the end reads an hour late. Reading the hour from the
                # start and the minutes and seconds from the end gives a
                # duration the recording can contain.
                alt = (t0 // 3600) * 3600 + (t1 % 3600)
                b2 = (alt - ref) % 86400
                if a < b2 <= a + MAX_SZ:
                    bsec, note = b2, "end corrected, transcription error"

            if bsec <= a:
                notes.append("%s/%s: end before start after correction" % (subj, key))
                continue
            if a > dur:
                notes.append("%s/%s: onset %.0f s beyond the recording (%.0f s)"
                             % (subj, key, a, dur))
                continue
            if bsec > dur:
                bsec, note = dur, note + "; end clipped"
            rows.append(dict(subject=subj, recording=key.lower(),
                             start_s=round(a, 1), end_s=round(bsec, 1),
                             duration_s=round(bsec - a, 1),
                             declared_file=(fn.group(1) if fn else ""), note=note))

    d = pd.DataFrame(rows)
    d.to_csv(OUT / "annotations.csv", index=False)
    log("%d seizures recovered\n" % len(d))
    info = SIENA / "subject_info.csv"
    if not d.empty and info.exists():
        per = d.groupby("subject").size()
        si = pd.read_csv(info)
        col = [c for c in si.columns if "seizure" in c.lower() and "number" in c.lower()]
        if col:
            log("  subject   recovered   listed")
            miss = 0
            for _, r in si.iterrows():
                s = str(r.iloc[0]).strip()
                got = int(per.get(s, 0)); want = int(r[col[0]])
                miss += abs(got - want)
                log("  %-8s  %4d        %4d%s"
                    % (s, got, want, "" if got == want else "   <-- %+d" % (got - want)))
            log("\n  total %d recovered against %d listed" % (len(d), si[col[0]].sum()))
            log("  %s" % ("every listed seizure is accounted for" if miss == 0
                          else "%d still unaccounted for" % miss))
        log("\n  durations: median %.0f s, range %.0f to %.0f"
            % (d.duration_s.median(), d.duration_s.min(), d.duration_s.max()))
        log("\n  how each was obtained:")
        for n, g in d.groupby("note"):
            log("    %-45s %d" % (n, len(g)))
        odd = d[d.declared_file.str.replace(".edf", "", regex=False).str.upper()
                != d.recording.str.upper()]
        if not odd.empty:
            log("\n  declared file name did not match the recording:")
            for _, r in odd.iterrows():
                log("    %-6s declared %-12s used %s"
                    % (r.subject, r.declared_file, r.recording))
    if notes:
        log("\n  unresolved:")
        for n in notes:
            log("    %s" % n)
    log("\nwritten to %s" % (OUT / "annotations.csv"))
    log("\nNext: have the feature extraction read this file instead of parsing")
    log("the text files, then rerun every analysis whose test set is Siena.")


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "diagnose"
    if what == "diagnose":
        diagnose()
    elif what == "rebuild":
        rebuild()
    else:
        sys.exit("usage: fix_labels.py diagnose | rebuild")
