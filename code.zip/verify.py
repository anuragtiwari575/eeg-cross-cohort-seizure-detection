"""
=============================================================================
VERIFY THE DATASET FACTS AND REDO THE PROBES LIKE FOR LIKE
=============================================================================
    python -u verify.py

Answers, from the data rather than from memory, the factual questions raised
about the Siena description and the montage, and reruns the feature probes
so that all three are measured the same way.

WHAT IS CHECKED

1. SIENA SEIZURE COUNT AND RECORDING TIME

   The manuscript says 44 annotated seizures, of which 43 are retained, and
   reports 141 hours for the cohort. PhysioNet's own description gives 47
   seizures and about 128 hours. Those do not agree, and one of them is
   wrong. This prints the per-subject seizure count parsed from the
   Seizures-list files beside the count in subject_info.csv, and the
   duration of every EDF from its header, so the discrepancy can be
   located rather than argued about.

2. PN00-3

   The manuscript excludes one annotation as a transcription error: it
   implies a 3660 s seizure. The recording itself ends at 18.57.13 while
   the annotation reads 18.28.29 to 19.29.29, so the end time is
   impossible but the start is not. Excluding the seizure discards a real
   event; correcting the end to 18.29.29, a 60 s seizure, does not. This
   prints the file duration and both interpretations.

3. THE MONTAGE

   The manuscript uses 17 bipolar derivations and says T8-P8 was excluded
   as a duplicate. The CHB-MIT summary files list 18 distinct derivations
   in the longitudinal chain plus a duplicate T8-P8, so after removing the
   duplicate there should be 18, not 17. This prints what is actually in
   the file and what the pipeline selects, so the missing one can be named.

4. THE PROBES, MEASURED THE SAME WAY

   Cohort and seizure identity are currently probed with subject-grouped
   folds while subject identity cannot be, since subject is its target.
   The three are therefore not comparable, and the comparison between them
   is what the paper uses. Grouping all three by recording makes them
   comparable: no recording appears on both sides of any split, and
   subject identity remains a well-posed target because most subjects have
   several recordings.

OUTPUT  printed, and D:\\verify\\ for the tables
=============================================================================
"""
from pathlib import Path
import sys, re, warnings, time
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd

SIENA = Path(r"D:\CPU-Intel 7\C_Drive\archive\siena-scalp-eeg-database-1.0.0")
CHB   = Path(r"D:\CPU-Intel 7\C_Drive\Compressed\chb-mit-scalp-eeg-database-1.0.0"
             r"\chb-mit-scalp-eeg-database-1.0.0")
CACHE = Path(r"D:\ablation\cache")
OUT   = Path(r"D:\verify"); OUT.mkdir(parents=True, exist_ok=True)
SEED  = 1234


def log(m): print(m, flush=True)


# ================================================================= 1 and 2
def siena_facts():
    log("=" * 72)
    log("1. SIENA: SEIZURES AND RECORDING TIME")
    log("=" * 72)
    if not SIENA.exists():
        log("  not found: %s" % SIENA); return

    import mne
    rows, ann = [], []
    for d in sorted(p for p in SIENA.iterdir() if p.is_dir()):
        subj = d.name
        edfs = sorted(d.glob("*.edf"))
        secs = 0.0
        for f in edfs:
            try:
                r = mne.io.read_raw_edf(f, preload=False, verbose="ERROR")
                secs += r.n_times / r.info["sfreq"]
                del r
            except Exception as e:
                log("    unreadable %s: %s" % (f.name, e))
        # seizures as annotated
        n = 0
        for lf in list(d.glob("Seizures-list*.txt")) + list(d.glob("*.txt")):
            txt = lf.read_text(errors="ignore")
            starts = re.findall(r"Registration start time:\s*([\d.:]+)", txt)
            ss = re.findall(r"Seizure start time:\s*([\d.:]+)", txt)
            es = re.findall(r"Seizure end time:\s*([\d.:]+)", txt)
            n = max(n, len(ss))
            for a, b in zip(ss, es):
                ann.append(dict(subject=subj, start=a, end=b))
            break
        rows.append(dict(subject=subj, n_edf=len(edfs), hours=secs / 3600,
                         seizures_parsed=n))
    d = pd.DataFrame(rows)
    d.to_csv(OUT / "siena_inventory.csv", index=False)
    log(d.round(2).to_string(index=False))
    log("\n  total: %d subjects, %d recordings, %.1f hours, %d seizures parsed"
        % (len(d), d.n_edf.sum(), d.hours.sum(), d.seizures_parsed.sum()))
    log("  the manuscript reports 14 subjects, 141 hours, 44 seizures (43 kept)")
    log("  PhysioNet's description gives 47 seizures and about 128 hours")

    info = SIENA / "subject_info.csv"
    if info.exists():
        try:
            si = pd.read_csv(info)
            log("\n  subject_info.csv:")
            log(si.to_string(index=False))
            for c in si.columns:
                if "seizure" in c.lower():
                    log("  seizures summed from that column: %s"
                        % pd.to_numeric(si[c], errors="coerce").sum())
                if "minute" in c.lower() or "duration" in c.lower():
                    v = pd.to_numeric(si[c], errors="coerce").sum()
                    log("  duration summed from %s: %.0f (= %.1f h if minutes)"
                        % (c, v, v / 60))
        except Exception as e:
            log("  could not read subject_info.csv: %s" % e)

    A = pd.DataFrame(ann)
    if not A.empty:
        A.to_csv(OUT / "siena_annotations.csv", index=False)

    log("\n" + "=" * 72)
    log("2. PN00-3")
    log("=" * 72)
    f = SIENA / "PN00" / "PN00-3.edf"
    if f.exists():
        r = mne.io.read_raw_edf(f, preload=False, verbose="ERROR")
        dur = r.n_times / r.info["sfreq"]
        log("  duration %.0f s (%.2f h); measurement date %s"
            % (dur, dur / 3600, r.info.get("meas_date")))
        log("  annotation reads 18.28.29 to 19.29.29, implying 3660 s")
        log("  the recording cannot contain that, so the end time is wrong")
        log("  reading the end as 18.29.29 gives a 60 s seizure, which it can")
        log("  -> correcting the end retains the event; excluding it loses one")
        del r
    else:
        log("  not found: %s" % f)


# ================================================================= 3
def montage():
    log("\n" + "=" * 72)
    log("3. THE MONTAGE")
    log("=" * 72)
    s = CHB / "chb01" / "chb01-summary.txt"
    if not s.exists():
        cand = list(CHB.glob("chb01/*summary*"))
        s = cand[0] if cand else None
    if s is None:
        log("  chb01 summary not found under %s" % CHB); return
    txt = s.read_text(errors="ignore")
    chans = re.findall(r"Channel\s+(\d+):\s*(\S+)", txt)
    names = [c[1] for c in chans]
    log("  %d channel entries in the summary" % len(names))
    seen, dupes, uniq = set(), [], []
    for n in names:
        (dupes if n in seen else uniq).append(n)
        seen.add(n)
    log("  %d distinct, %d duplicated: %s" % (len(uniq), len(dupes), dupes))
    log("\n  distinct list:")
    for i in range(0, len(uniq), 6):
        log("    " + "  ".join("%-9s" % u for u in uniq[i:i + 6]))

    try:
        import importlib.util
        for c in (Path(__file__).parent / "xcohort.py",
                  Path(r"D:\eeg_project\xcohort.py")):
            if c.exists():
                sp = importlib.util.spec_from_file_location("xc", str(c))
                m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
                used = [b[0] for b in m.BIPOLAR]
                log("\n  the pipeline selects %d: %s" % (len(used), used))
                miss = [u for u in uniq if u not in used and "-" in u]
                log("  in the file but not selected: %s" % (miss or "none"))
                break
    except Exception as e:
        log("  could not read the pipeline montage: %s" % e)


# ================================================================= 4
def probes():
    log("\n" + "=" * 72)
    log("4. PROBES WITH RECORDING-GROUPED FOLDS")
    log("=" * 72)
    log("All three targets measured the same way: folds grouped by recording,")
    log("so no recording appears on both sides of a split and subject")
    log("identity stays well posed, most subjects having several recordings.\n")
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    from sklearn.model_selection import GroupKFold, StratifiedKFold, cross_val_score

    fs = sorted(CACHE.glob("*.npz"))
    if not fs:
        log("  no cache in %s -- run ablation.py first" % CACHE); return
    rng = np.random.default_rng(SEED)
    X, y, sub, coh, rec = [], [], [], [], []
    for f in fs:
        d = np.load(f, allow_pickle=True)
        if d["X"].size == 0:
            continue
        n = len(d["y"])
        k = rng.choice(n, min(500, n), replace=False)
        pos = np.where(d["y"] == 1)[0]
        k = np.unique(np.concatenate([k, pos]))
        X.append(d["X"][k]); y.append(d["y"][k])
        sub.append(np.full(len(k), f.stem))
        coh.append(np.full(len(k), "chb" if f.stem.lower().startswith("chb")
                           else "siena"))
        rec.append(d["rec"][k].astype(str) if "rec" in d.files
                   else np.full(len(k), f.stem))
    X = np.vstack(X)[:, :170]          # A+B+C, the arm the paper uses
    y = np.concatenate(y); sub = np.concatenate(sub)
    coh = np.concatenate(coh); rec = np.concatenate(rec)
    ok = np.isfinite(X).all(1)
    X, y, sub, coh, rec = X[ok], y[ok], sub[ok], coh[ok], rec[ok]
    log("  %d windows, %d features, %d recordings, %d subjects"
        % (len(y), X.shape[1], len(np.unique(rec)), len(np.unique(sub))))

    def lr():
        return make_pipeline(StandardScaler(),
                             LogisticRegression(max_iter=1000,
                                                class_weight="balanced"))

    gkf = GroupKFold(n_splits=5)
    skf = StratifiedKFold(5, shuffle=True, random_state=SEED)
    rows = []

    ci = pd.factorize(coh)[0]
    rows.append(dict(target="cohort",
                     recording_grouped=cross_val_score(
                         lr(), X, ci, cv=gkf.split(X, ci, rec),
                         scoring="roc_auc").mean(),
                     subject_grouped=cross_val_score(
                         lr(), X, ci, cv=gkf.split(X, ci, sub),
                         scoring="roc_auc").mean(),
                     ungrouped=cross_val_score(lr(), X, ci, cv=skf,
                                               scoring="roc_auc").mean()))

    rows.append(dict(target="seizure",
                     recording_grouped=cross_val_score(
                         lr(), X, y, cv=gkf.split(X, y, rec),
                         scoring="roc_auc").mean(),
                     subject_grouped=cross_val_score(
                         lr(), X, y, cv=gkf.split(X, y, sub),
                         scoring="roc_auc").mean(),
                     ungrouped=cross_val_score(lr(), X, y, cv=skf,
                                               scoring="roc_auc").mean()))

    rg, ug = [], []
    for s in np.unique(sub):
        lab = (sub == s).astype(int)
        if lab.sum() < 50 or len(np.unique(rec[sub == s])) < 2:
            continue
        try:
            rg.append(cross_val_score(lr(), X, lab, cv=gkf.split(X, lab, rec),
                                      scoring="roc_auc").mean())
            ug.append(cross_val_score(lr(), X, lab, cv=skf,
                                      scoring="roc_auc").mean())
        except Exception:
            pass
    if rg:
        rows.append(dict(target="subject", recording_grouped=float(np.mean(rg)),
                         subject_grouped=np.nan, ungrouped=float(np.mean(ug))))

    d = pd.DataFrame(rows)
    d.to_csv(OUT / "probes_recording_grouped.csv", index=False)
    log("\n" + d.round(3).to_string(index=False))
    log("\n  The recording-grouped column is the like-for-like comparison:")
    log("  all three targets, one protocol. Subject identity cannot be")
    log("  subject-grouped, which is why that cell is blank.")


if __name__ == "__main__":
    t0 = time.time()
    for fn in (siena_facts, montage, probes):
        try:
            fn()
        except Exception as e:
            log("FAILED %s: %s: %s" % (fn.__name__, type(e).__name__, e))
            import traceback; traceback.print_exc()
    log("\n%.1f min | results in %s" % ((time.time() - t0) / 60, OUT))
