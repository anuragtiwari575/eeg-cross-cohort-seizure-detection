"""
=============================================================================
CAUSAL NORMALISATION, BOTH ARMS AND BOTH BOUNDARIES
=============================================================================
    python -u normalisation2.py

Split off from analysis.py because it recomputes the temporal features three
times over the whole set and takes about an hour.

WHY BOTH BOUNDARIES

Whole-recording z-scoring uses each test recording's own mean and standard
deviation. That removes gain and amplitude differences between recordings,
and amplitude is one of the things that differs between a paediatric cohort
and an adult one. So part of what the paper reports as a cheap cohort
boundary may be the normalisation rather than the representation. The
earlier run covered the cross-cohort setting only, which cannot answer that:
if causal normalisation costs the same at both boundaries the concern is
unfounded, and if it costs more at the cohort boundary it is not.

WHY BOTH ARMS

Relative band power is a ratio of powers within a window and the aperiodic
exponent is a slope on log axes, so both are invariant to a per-channel
rescaling and take identical values under every normalisation rule. Only
line length and the Teager-Kaiser operator move. This means the feature-set
result and the normalisation result are not independent: the temporal
family's contribution is measured under whole-recording normalisation, and
under a causal rule it will be smaller. Running both arms makes the
interaction visible instead of leaving it to be inferred.

THE THREE RULES

    whole   mean and standard deviation of the complete recording; what
            the paper uses, and not available to a prospective system
    lead    statistics from the first 120 s of each recording
    pre     statistics from the 30 s preceding each window

The stored windows are already whole-recording z-scored. That does not
matter: z-scoring is affine, so applying a causal rescale on top gives
exactly what applying it to the raw signal would give, the recording-level
mean and standard deviation cancelling. In float16 the identity holds to
about 5e-3 in standardised units.

The 30 s rule adapts during a seizure, which suppresses the amplitude rise
the temporal features detect, so its cost is partly a property of that
window length rather than of causality as such. Both are reported.

OUTPUT  D:\\analysis\\normalisation.csv
=============================================================================
"""
from pathlib import Path
import sys, time, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd

CACHE  = Path(r"D:\ablation\cache")
SHARDS = Path(r"D:\xcohort_full")
OUT    = Path(r"D:\analysis"); OUT.mkdir(parents=True, exist_ok=True)

WIN_S, SEED, NB, MAX_TRAIN = 4.0, 1234, 85, 150_000
LEAD_S, PRE_S = 120.0, 30.0
BATCH = 4096

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GroupKFold

def log(m): print(m, flush=True)


# ------------------------------------------------ spectral features, once
log("loading the spectral features (invariant to the rule, so computed once)")
sp, y, sub, coh = [], [], [], []
for f in sorted(CACHE.glob("*.npz")):
    d = np.load(f, allow_pickle=True)
    if d["X"].size == 0:
        continue
    sp.append(d["X"][:, :119]); y.append(d["y"])
    sub.append(np.full(len(d["y"]), f.stem))
    coh.append(np.full(len(d["y"]), "chb" if f.stem.lower().startswith("chb") else "siena"))
SP = np.vstack(sp).astype(np.float32)
y = np.concatenate(y); sub = np.concatenate(sub); coh = np.concatenate(coh)
patient = np.where(sub == "chb21", "chb01", sub)
log("  %d windows, %d spectral features" % (len(y), SP.shape[1]))


def temporal(W):
    """Line length and Teager-Kaiser, in batches and float32."""
    n, c, t = W.shape
    out = np.empty((n, c * 3), np.float32)
    for i in range(0, n, BATCH):
        w = W[i:i+BATCH].astype(np.float32)
        ll = np.abs(np.diff(w, axis=2)).sum(2)
        p = w[:, :, 1:-1]**2 - w[:, :, :-2]*w[:, :, 2:]
        out[i:i+BATCH] = np.concatenate([ll, p.mean(2), p.std(2)], 1)
        del w, p
    return out


def renormalise(W, rc, od, mode):
    if mode == "whole":
        return W
    lead_n, pre_n = int(LEAD_S / WIN_S), int(PRE_S / WIN_S)
    out = np.empty_like(W)
    for r in np.unique(rc):
        m = np.where(rc == r)[0]; m = m[np.argsort(od[m])]
        blk = W[m]
        if mode == "lead":
            ref = blk[:min(lead_n, len(blk))]
            mu = ref.mean((0, 2), keepdims=True)
            sd = ref.std((0, 2), keepdims=True) + 1e-6
            out[m] = (blk - mu) / sd
        else:
            o2 = np.empty_like(blk)
            for j in range(len(blk)):
                a = max(0, j - pre_n)
                ref = blk[a:j] if j > a else blk[:1]
                o2[j] = (blk[j] - ref.mean((0, 2), keepdims=True)[0]) / \
                        (ref.std((0, 2), keepdims=True)[0] + 1e-6)
            out[m] = o2
    return out


# ------------------------------------------------ temporal, three ways
log("\nrecomputing the temporal features under each rule")
store = {k: [] for k in ("whole", "lead", "pre")}
keep_sub = []
t0 = time.time()
files = [f for f in sorted(SHARDS.glob("*.npz")) if f.stem != "manifest"]
for i, f in enumerate(files, 1):
    z = np.load(f, allow_pickle=True)
    if z["X"].size == 0:
        continue
    W = z["X"]
    key = "rec" if "rec" in z.files else "file"
    rc = z[key].astype(str); od = z["order"].astype(int)
    for mode in ("whole", "lead", "pre"):
        Wm = renormalise(W, rc, od, mode)
        store[mode].append(temporal(Wm))
        if Wm is not W:
            del Wm
    keep_sub.append(np.full(len(z["y"]), f.stem))
    log("  [%2d/%d] %-7s (%.1f min)" % (i, len(files), f.stem, (time.time()-t0)/60))

ksub = np.concatenate(keep_sub)
if len(ksub) != len(y):
    sys.exit("shards and cache disagree: %d against %d windows" % (len(ksub), len(y)))
if not (ksub == sub).all():
    sys.exit("shard order does not match the cache; stopping rather than "
             "guessing an alignment")


# ------------------------------------------------ evaluate
def fit(F, tr, te):
    Xtr, ytr = F[tr], y[tr]
    if len(ytr) > MAX_TRAIN:
        g = np.random.default_rng(SEED)
        p = np.where(ytr == 1)[0]; n = np.where(ytr == 0)[0]
        n = g.choice(n, max(1, min(len(n), MAX_TRAIN - len(p))), replace=False)
        k = np.concatenate([p, n]); Xtr, ytr = Xtr[k], ytr[k]
    m = make_pipeline(StandardScaler(),
                      LogisticRegression(max_iter=1000, class_weight="balanced"))
    m.fit(Xtr, ytr)
    return m.predict_proba(F[te])[:, 1]


rows = []
CHB = np.where(coh == "chb")[0]; SIE = np.where(coh == "siena")[0]
for mode in ("whole", "lead", "pre"):
    T = np.vstack(store[mode])
    for arm, F in (("AB", SP), ("ABC", np.hstack([SP, T]))):
        ok = np.isfinite(F).all(1)
        C = np.intersect1d(CHB, np.where(ok)[0])
        S = np.intersect1d(SIE, np.where(ok)[0])
        for tag, tr, te in (("S3fwd", C, S), ("S3rev", S, C)):
            rows.append(dict(normalisation=mode, arm=arm, setting=tag,
                             auroc=float(roc_auc_score(y[te], fit(F, tr, te)))))
        a = []
        for tr_i, te_i in GroupKFold(5).split(C, y[C], patient[C]):
            trf, tef = C[tr_i], C[te_i]
            if len(np.unique(y[tef])) < 2:
                continue
            a.append(roc_auc_score(y[tef], fit(F, trf, tef)))
        rows.append(dict(normalisation=mode, arm=arm, setting="S2",
                         auroc=float(np.mean(a))))
        log("  %-5s %-4s  S2 %.3f  S3fwd %.3f  S3rev %.3f"
            % (mode, arm, rows[-1]["auroc"], rows[-3]["auroc"], rows[-2]["auroc"]))

d = pd.DataFrame(rows)
d.to_csv(OUT / "normalisation.csv", index=False)

log("\n" + "#" * 68)
piv = d.pivot_table(index=["arm", "normalisation"], columns="setting", values="auroc")
log(piv.round(3).to_string())

log("\nwhat to read from it:")
w = d[d.normalisation == "whole"].set_index(["arm", "setting"]).auroc
for mode in ("lead", "pre"):
    m = d[d.normalisation == mode].set_index(["arm", "setting"]).auroc
    log("\n  %s minus whole-recording:" % mode)
    for arm in ("AB", "ABC"):
        for st in ("S2", "S3fwd", "S3rev"):
            if (arm, st) in m.index and (arm, st) in w.index:
                log("    %-4s %-6s %+.3f" % (arm, st, m[(arm, st)] - w[(arm, st)]))
    s2 = np.mean([m[("ABC", "S2")] - w[("ABC", "S2")]])
    s3 = np.mean([m[("ABC", t)] - w[("ABC", t)] for t in ("S3fwd", "S3rev")])
    log("    cohort boundary loses %+.3f more than the patient boundary"
        % (s3 - s2))

log("\n  If the cohort boundary loses more, part of what the paper reports as a")
log("  cheap cohort boundary was the normalisation. If the two lose equally,")
log("  the concern is unfounded and can be said so.")
log("\n  The spectral arm should be identical across rules; any difference there")
log("  is numerical noise and bounds the precision of the comparison.")
log("\nwritten to %s" % (OUT / "normalisation.csv"))
