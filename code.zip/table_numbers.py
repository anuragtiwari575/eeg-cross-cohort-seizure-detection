"""
Prints the per-direction cross-cohort numbers for tables 3 and 5.

    python -u table_numbers.py

Reads what is already on disk. Nothing is refitted.
"""
from pathlib import Path
import numpy as np, pandas as pd

ABL = Path(r"D:\ablation\results\ablation.csv")
NAT = Path(r"D:\native_inference\results\native_metrics_all.csv")
TARGETS = [0.50, 0.25, 0.10, 0.0736, 0.05, 0.01]

print("=" * 68)
print("HANDCRAFTED, cross-cohort, native prevalence")
print("=" * 68)
if ABL.exists():
    d = pd.read_csv(ABL)
    m = np.zeros(len(d), bool)
    for t in TARGETS:
        m |= np.isclose(d.target_prev, t)
    n = d[~m]
    s3 = n[n.setting.str.startswith("S3")]
    for setting in ("S3-fwd", "S3-rev"):
        g = s3[s3.setting == setting]
        if g.empty:
            continue
        print("\n--- %s  (base rate %.5f) ---" % (setting, g.prevalence.iloc[0]))
        print(g.set_index("features")[["auroc", "auprc", "lift"]]
               .round(4).to_string())
    print("\n--- pooled over the two directions ---")
    print(s3.groupby("features")[["auroc", "auprc", "lift"]].mean()
            .round(4).to_string())

    print("\n--- matched 7.36 per cent ---")
    mm = d[np.isclose(d.target_prev, 0.0736)]
    mm = mm[mm.setting.str.startswith("S3")]
    print(mm.groupby("features")[["auroc", "auprc"]].mean().round(4).to_string())
else:
    print("not found:", ABL)

print("\n" + "=" * 68)
print("LEARNED, cross-cohort, native prevalence")
print("=" * 68)
if NAT.exists():
    d = pd.read_csv(NAT)
    s = d[d.setting == "S3"]
    print(s.groupby("fold")[["auroc", "auprc", "lift", "prevalence"]]
           .mean().round(4).to_string())
    print("\npooled: " + ", ".join(
        "%s %.4f" % (k, v) for k, v in
        s[["auroc", "auprc", "lift"]].mean().round(4).items()))
    print("\nby architecture and direction:")
    print(s.pivot_table(index="model", columns="fold",
                        values=["auroc", "auprc"]).round(4).to_string())
    s1 = d[d.setting == "S1"]
    if not s1.empty:
        print("\nS1 pooled: " + ", ".join(
            "%s %.4f" % (k, v) for k, v in
            s1[["auroc", "auprc", "lift", "prevalence"]].mean().round(4).items()))
else:
    print("not found:", NAT)
