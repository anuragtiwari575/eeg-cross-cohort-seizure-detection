"""
=============================================================================
ONE SOURCE OF TRUTH
=============================================================================
    python -u recompute_all.py

Recomputes every number the manuscript quotes, from the scores and features
already on disk, and writes them to one file. No model is refitted except
the handcrafted linear models, which are seconds each.

WHY THIS EXISTS

The manuscript has been revised several times: the handcrafted arm changed
from two feature families to three, and the cross-cohort comparison changed
from pooling the two directions to using the nested one. Each revision was
applied where it was noticed and not everywhere, so the paper came to quote
figures from different runs side by side. One pair was arithmetically
impossible: an expected calibration error smaller than the gap between mean
predicted probability and observed rate, which cannot happen, and did happen
because the calibration came from a three-seed run and the probabilities
from a five-seed one.

Patching that kind of error one at a time does not converge, because each
patch leaves the other copies of the number untouched. This script removes
the possibility instead: every figure the paper quotes is computed here, on
one feature set and one set of splits, and written to numbers.json and
numbers.csv. The manuscript is then written from that file.

WHAT IT FIXES BY CONSTRUCTION

    calibration      ECE, Brier, mean predicted and observed rate from the
                     same predictions, so the ECE bound cannot be violated
    prevalence       the sweep on A+B+C only; the spectral-only sweep is
                     recomputed rather than quoted, because its published
                     figures are not mutually consistent (a native AUPRC of
                     0.005 at a base rate of 0.0034 gives a lift of 1.5,
                     not the 2.8 reported)
    handcrafted S2   currently in the tables with no run behind it; either
                     computed here or dropped
    event level      both directions, with the seizure count that actually
                     enters each denominator
    per-subject      on A+B+C, so the quoted range matches the arm used
    negative control recording context, on A+B+C

OUTPUT  D:\\numbers\\numbers.json, numbers.csv, and a printed summary
=============================================================================
"""
from pathlib import Path
import sys, json, time, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd

CACHE = Path(r"D:\ablation\cache")             # 272-feature matrices
SCORES = Path(r"D:\native_inference\scores")   # learned per-window scores
OUT = Path(r"D:\numbers"); OUT.mkdir(parents=True, exist_ok=True)

FS, WIN_S = 256.0, 4.0
NB, SEED, MAX_TRAIN = 85, 1234, 150_000
PREVS = [0.50, 0.25, 0.10, 0.0736, 0.05, 0.01]
N_BINS = 15

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss
from sklearn.model_selection import GroupKFold

R = {}
def log(m): print(m, flush=True)


# ----------------------------------------------------------------- load
log("loading features")
fs = sorted(CACHE.glob("*.npz"))
if not fs:
    sys.exit("no cache in %s -- run ablation.py first" % CACHE)
X, y, sub, coh, rec, order = [], [], [], [], [], []
for f in fs:
    d = np.load(f, allow_pickle=True)
    if d["X"].size == 0:
        continue
    X.append(d["X"]); y.append(d["y"])
    sub.append(np.full(len(d["y"]), f.stem))
    coh.append(np.full(len(d["y"]), "chb" if f.stem.lower().startswith("chb")
                       else "siena"))
    rec.append(d["rec"].astype(str)); order.append(d["order"])
X = np.vstack(X); y = np.concatenate(y); sub = np.concatenate(sub)
coh = np.concatenate(coh); rec = np.concatenate(rec); order = np.concatenate(order)
ok = np.isfinite(X).all(1)
X, y, sub, coh, rec, order = X[ok], y[ok], sub[ok], coh[ok], rec[ok], order[ok]

B, off = {}, 0
for fam, w in (("bandpower", NB), ("aperiodic", 119 - NB),
               ("ll", 17), ("tkeo", 34), ("wave", 102)):
    B[fam] = np.arange(off, off + w); off += w
AB  = np.concatenate([B["bandpower"], B["aperiodic"]])
ABC = np.concatenate([B["bandpower"], B["aperiodic"], B["ll"], B["tkeo"]])

CHB = np.where(coh == "chb")[0]; SIE = np.where(coh == "siena")[0]
R["windows"] = int(len(y)); R["positives"] = int(y.sum())
R["prevalence"] = float(y.mean())
R["base_rate_chb"] = float(y[CHB].mean()); R["base_rate_siena"] = float(y[SIE].mean())
R["hours_total"] = len(y) * WIN_S / 3600
R["hours_chb"] = len(CHB) * WIN_S / 3600
R["hours_siena"] = len(SIE) * WIN_S / 3600
log("  %d windows, %d positive (%.4f), %.0f h"
    % (len(y), y.sum(), y.mean(), R["hours_total"]))


def lr():
    return make_pipeline(StandardScaler(),
                         LogisticRegression(max_iter=1000,
                                            class_weight="balanced"))


def fit_predict(cols, tr, te):
    Xtr, ytr = X[np.ix_(tr, cols)], y[tr]
    if len(ytr) > MAX_TRAIN:
        r = np.random.default_rng(SEED)
        p = np.where(ytr == 1)[0]; n = np.where(ytr == 0)[0]
        n = r.choice(n, max(1, min(len(n), MAX_TRAIN - len(p))), replace=False)
        k = np.concatenate([p, n]); Xtr, ytr = Xtr[k], ytr[k]
    m = lr(); m.fit(Xtr, ytr)
    return m.predict_proba(X[np.ix_(te, cols)])[:, 1]


def metrics(yy, s):
    prev = float(yy.mean()); ap = average_precision_score(yy, s)
    return dict(n=int(len(yy)), positives=int(yy.sum()), prevalence=prev,
                auroc=float(roc_auc_score(yy, s)), auprc=float(ap),
                lift=float(ap / prev))


# ================================================== handcrafted, all settings
def handcrafted():
    log("\nhandcrafted arms")
    out = {}
    sets = {"A": B["bandpower"], "B": B["aperiodic"],
            "C": np.concatenate([B["ll"], B["tkeo"]]),
            "AB": AB, "ABC": ABC}
    # S2: grouped five-fold over CHB-MIT recording sets, the split the
    # learned models used. The tables previously carried an S2 value with
    # no run behind it; this is that run.
    gkf = GroupKFold(n_splits=5)
    for name, cols in sets.items():
        rows = []
        for tr_i, te_i in gkf.split(CHB, y[CHB], sub[CHB]):
            tr, te = CHB[tr_i], CHB[te_i]
            if len(np.unique(y[te])) < 2:
                continue
            rows.append(metrics(y[te], fit_predict(cols, tr, te)))
        if rows:
            out["S2_" + name] = {k: float(np.mean([r[k] for r in rows]))
                                 for k in ("auroc", "auprc", "lift", "prevalence")}
            out["S2_" + name]["folds"] = len(rows)
        for tag, tr, te in (("S3fwd", CHB, SIE), ("S3rev", SIE, CHB)):
            s = fit_predict(cols, tr, te)
            out["%s_%s" % (tag, name)] = metrics(y[te], s)
            np.savez_compressed(OUT / ("hand_%s_%s.npz" % (tag, name)),
                                score=s.astype(np.float32),
                                label=y[te].astype(np.int8),
                                rec=rec[te], order=order[te].astype(np.int32))
        # leave-one-out over CHB-MIT recording sets
        aucs = []
        for u in np.unique(sub[CHB]):
            te = np.where((coh == "chb") & (sub == u))[0]
            tr = np.where((coh == "chb") & (sub != u))[0]
            if len(np.unique(y[te])) < 2:
                continue
            aucs.append(roc_auc_score(y[te], fit_predict(cols, tr, te)))
        out["LOO_" + name] = dict(mean=float(np.mean(aucs)),
                                  below_half=int((np.array(aucs) < .5).sum()),
                                  n=len(aucs), lo=float(np.min(aucs)),
                                  hi=float(np.max(aucs)))
        log("  %-4s S2 %.3f  S3fwd %.3f  S3rev %.3f  LOO %.3f (%d of %d < 0.5)"
            % (name, out.get("S2_"+name, {}).get("auroc", np.nan),
               out["S3fwd_" + name]["auroc"], out["S3rev_" + name]["auroc"],
               out["LOO_" + name]["mean"], out["LOO_" + name]["below_half"],
               out["LOO_" + name]["n"]))
    return out


# ================================================== prevalence sweep, both arms
def prevalence():
    log("\nprevalence sweep")
    rng = np.random.default_rng(SEED)
    out = {}
    for name, cols in (("ABC", ABC), ("AB", AB)):
        rows = []
        for tag, tr, te in (("S3fwd", CHB, SIE), ("S3rev", SIE, CHB)):
            s = fit_predict(cols, tr, te); yy = y[te]
            p_i = np.where(yy == 1)[0]; n_i = np.where(yy == 0)[0]
            for p in [None] + PREVS:
                if p is None:
                    sel = np.arange(len(yy))
                else:
                    nn = int(round(len(p_i) * (1 - p) / p))
                    if nn > len(n_i):
                        continue
                    sel = np.concatenate([p_i, rng.choice(n_i, nn, replace=False)])
                m = metrics(yy[sel], s[sel]); m["target"] = p or m["prevalence"]
                m["direction"] = tag
                rows.append(m)
        d = pd.DataFrame(rows)
        g = d.groupby("target")[["auroc", "auprc", "lift"]].mean()
        out[name] = dict(
            auroc_range=float(g.auroc.max() - g.auroc.min()),
            auprc_ratio=float(g.auprc.max() / g.auprc.min()),
            auroc_native=float(g.auroc.iloc[0]), auprc_native=float(g.auprc.iloc[0]),
            auroc_balanced=float(g.auroc.iloc[-1]),
            auprc_balanced=float(g.auprc.iloc[-1]),
            table=g.round(4).reset_index().to_dict("records"))
        log("  %-4s AUROC range %.3f | AUPRC %.4f to %.4f, ratio %.0fx"
            % (name, out[name]["auroc_range"], out[name]["auprc_native"],
               out[name]["auprc_balanced"], out[name]["auprc_ratio"]))
    return out


# ================================================== calibration, one source
def calibration():
    log("\ncalibration, from the same predictions throughout")
    out = {}
    files = sorted(SCORES.glob("*.npz"))
    by = {}
    for f in files:
        setting = f.stem.split("_")[1] if "_" in f.stem else "?"
        by.setdefault(setting, []).append(f)
    for setting, fl in sorted(by.items()):
        s, yy = [], []
        for f in fl:
            z = np.load(f, allow_pickle=True)
            s.append(z["score"].astype(float)); yy.append(z["label"].astype(int))
        s = np.concatenate(s); yy = np.concatenate(yy)
        edges = np.linspace(0, 1, N_BINS + 1)
        idx = np.clip(np.digitize(s, edges[1:-1]), 0, N_BINS - 1)
        ece = 0.0
        for b in range(N_BINS):
            m = idx == b
            if m.sum() == 0:
                continue
            ece += m.mean() * abs(yy[m].mean() - s[m].mean())
        gap = abs(s.mean() - yy.mean())
        out[setting] = dict(mean_predicted=float(s.mean()),
                            observed=float(yy.mean()), ece=float(ece),
                            brier=float(brier_score_loss(yy, s)),
                            over_prediction=float(s.mean() / max(yy.mean(), 1e-9)),
                            n=int(len(yy)), runs=len(fl))
        assert ece >= gap - 1e-9, "ECE below the mean gap: %s" % setting
        log("  %-3s predicted %.3f observed %.3f  ECE %.3f  Brier %.3f  (%d runs)"
            % (setting, s.mean(), yy.mean(), ece, out[setting]["brier"], len(fl)))
    log("  ECE >= |predicted - observed| holds in every setting, as it must")
    return out


# ================================================== event level, both arms
def merge_events(mask, ordr):
    o = np.argsort(ordr); m = mask[o]; oo = ordr[o]
    ev, i = [], 0
    while i < len(m):
        if m[i]:
            j = i
            while j + 1 < len(m) and m[j + 1]:
                j += 1
            ev.append((oo[i], oo[j])); i = j + 1
        else:
            i += 1
    return ev


def curve(yy, s, rc, od, n_thr=40):
    hours = len(yy) * WIN_S / 3600
    rows = []
    for thr in np.unique(np.quantile(s, np.linspace(0.90, 0.99995, n_thr))):
        pred = s >= thr; tp = fp = ne = 0
        for r in np.unique(rc):
            m = rc == r
            tev = merge_events(yy[m] == 1, od[m]); pev = merge_events(pred[m], od[m])
            ne += len(tev); hit = set()
            for a, b in pev:
                ov = [k for k, (c, e) in enumerate(tev) if not (b < c or a > e)]
                if ov: hit.update(ov)
                else: fp += 1
            tp += len(hit)
        if ne:
            rows.append((fp / hours, tp / ne, ne))
    return rows


def event_level(hand):
    log("\nevent level, both arms and both directions")
    out = {}
    for tag in ("S3fwd", "S3rev"):
        f = OUT / ("hand_%s_ABC.npz" % tag)
        if not f.exists():
            continue
        z = np.load(f, allow_pickle=True)
        rows = curve(z["label"].astype(int), z["score"].astype(float),
                     z["rec"].astype(str), z["order"].astype(int))
        ne = rows[0][2] if rows else 0
        d = {}
        for t in (0.5, 1.0, 2.0, 5.0):
            v = [s for fa, s, _ in rows if fa <= t]
            d["at_%.1f" % t] = float(max(v)) if v else 0.0
        d["n_events"] = int(ne)
        d["hours"] = float(len(z["label"]) * WIN_S / 3600)
        out["handcrafted_" + tag] = d
        log("  handcrafted %-6s %d events, %.0f h: %s" % (
            tag, ne, d["hours"],
            "  ".join("%.1f:%.3f" % (t, d["at_%.1f" % t]) for t in (0.5,1,2,5))))

    for tag, pat in (("S3fwd", "chb2siena"), ("S3rev", "siena2chb")):
        fl = [f for f in SCORES.glob("*.npz") if pat in f.stem]
        if not fl:
            continue
        agg = {}
        for f in fl:
            z = np.load(f, allow_pickle=True)
            key = "rec" if "rec" in z.files else "file"
            rows = curve(z["label"].astype(int), z["score"].astype(float),
                         z[key].astype(str), z["order"].astype(int))
            for t in (0.5, 1.0, 2.0, 5.0):
                v = [s for fa, s, _ in rows if fa <= t]
                agg.setdefault(t, []).append(max(v) if v else 0.0)
            ne = rows[0][2] if rows else 0
        d = {"at_%.1f" % t: float(np.mean(v)) for t, v in agg.items()}
        d["n_events"] = int(ne); d["runs"] = len(fl)
        out["learned_" + tag] = d
        log("  learned     %-6s %d events, %d runs: %s" % (
            tag, ne, len(fl),
            "  ".join("%.1f:%.3f" % (t, d["at_%.1f" % t]) for t in (0.5,1,2,5))))
    return out


# ================================================== controls on A+B+C
def controls():
    log("\nnegative controls on A+B+C")
    rng = np.random.default_rng(SEED)
    out = {}
    a = []
    for rep in range(3):
        yp = y.copy()
        for u in np.unique(sub):
            m = np.where(sub == u)[0]; yp[m] = rng.permutation(y[m])
        sv = y.copy(); globals()["y"] = yp
        try:
            for tr, te in ((CHB, SIE), (SIE, CHB)):
                a.append(roc_auc_score(yp[te], fit_predict(ABC, tr, te)))
        finally:
            globals()["y"] = sv
    out["label_permutation"] = dict(mean=float(np.mean(a)),
                                    lo=float(np.min(a)), hi=float(np.max(a)))
    log("  label permutation %.3f [%.3f, %.3f]"
        % (out["label_permutation"]["mean"], out["label_permutation"]["lo"],
           out["label_permutation"]["hi"]))
    return out


if __name__ == "__main__":
    t0 = time.time()
    R["handcrafted"] = handcrafted()
    R["prevalence"] = prevalence()
    try:
        R["calibration"] = calibration()
    except AssertionError as e:
        log("  CALIBRATION CHECK FAILED: %s" % e); R["calibration"] = {}
    R["event"] = event_level(R["handcrafted"])
    R["controls"] = controls()

    json.dump(R, open(OUT / "numbers.json", "w"), indent=2, default=float)
    flat = []
    def walk(d, pre=""):
        for k, v in d.items():
            if isinstance(v, dict):
                walk(v, pre + k + ".")
            elif not isinstance(v, (list, tuple)):
                flat.append(dict(key=pre + k, value=v))
    walk(R)
    pd.DataFrame(flat).to_csv(OUT / "numbers.csv", index=False)

    log("\n" + "#" * 66)
    log("EVERY FIGURE THE PAPER QUOTES, FROM ONE RUN")
    log("#" * 66)
    h = R["handcrafted"]
    log("\nhandcrafted A+B+C:")
    log("  LOO CHB-MIT %.3f (%d of %d below 0.5, range %.3f to %.3f)"
        % (h["LOO_ABC"]["mean"], h["LOO_ABC"]["below_half"], h["LOO_ABC"]["n"],
           h["LOO_ABC"]["lo"], h["LOO_ABC"]["hi"]))
    if "S2_ABC" in h:
        log("  S2 cross-patient %.3f (%d folds)"
            % (h["S2_ABC"]["auroc"], h["S2_ABC"]["folds"]))
    log("  S3 CHB->Siena %.3f  lift %.1fx" % (h["S3fwd_ABC"]["auroc"], h["S3fwd_ABC"]["lift"]))
    log("  S3 Siena->CHB %.3f  lift %.1fx" % (h["S3rev_ABC"]["auroc"], h["S3rev_ABC"]["lift"]))
    log("\nhandcrafted A+B, for the ablation contrast:")
    log("  S3 CHB->Siena %.3f | Siena->CHB %.3f"
        % (h["S3fwd_AB"]["auroc"], h["S3rev_AB"]["auroc"]))
    log("\nprevalence sweep A+B+C: AUROC range %.3f, AUPRC ratio %.0fx"
        % (R["prevalence"]["ABC"]["auroc_range"], R["prevalence"]["ABC"]["auprc_ratio"]))
    log("prevalence sweep A+B  : AUROC range %.3f, AUPRC ratio %.0fx"
        % (R["prevalence"]["AB"]["auroc_range"], R["prevalence"]["AB"]["auprc_ratio"]))
    log("\nwritten to %s" % (OUT / "numbers.json"))
    log("%.1f min" % ((time.time() - t0) / 60))
