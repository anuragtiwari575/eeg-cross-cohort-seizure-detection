"""
=============================================================================
THE TWO RETRAINING JOBS THAT COULD STILL CHANGE THE ANSWER
=============================================================================
    python -u retrain.py                 both jobs
    python -u retrain.py causal          normalisation only
    python -u retrain.py seeds           the two architectures only

Kaggle or a local GPU. Roughly four hours for both.

WHY THESE TWO

Everything else outstanding would change a number. These two could change a
conclusion, so they are worth running before submission rather than after.

1  THE LEARNED ARM UNDER CAUSAL NORMALISATION

   The handcrafted arm loses 0.020 at the patient boundary and 0.087 at the
   cohort boundary when normalisation statistics are restricted to the first
   two minutes of each recording. If the learned arm behaves the same way,
   the cohort boundary is even more expensive than reported and the paper's
   ordering is reinforced. If it behaves differently, the comparison between
   the two arms is itself conditional on the normalisation, and the
   representation section has to say so.

   This cannot be answered by rescoring. The models were trained on
   whole-recording normalised windows, so scoring them on causally
   normalised ones measures distribution shift rather than the effect of the
   rule. They have to be retrained under it, which is what this does, for
   S2 and S3 at one seed.

2  THE TWO ARCHITECTURES THAT WERE NEVER RERUN

   EEGTCNet and SincShallowNet returned S1 below S2 in the single-seed
   sweep, an ordering that is either a real property of those models on
   eight subjects or an artefact of one draw. They are not among the four
   rerun with five seeds, so the paper cannot say which, and currently says
   so. Running them closes that.

WHAT THIS DOES NOT DO

   It does not retrain under the thirty-second rule, which adapts during a
   seizure and whose cost is partly a property of that window length rather
   than of causality. One causal rule is enough to answer whether the effect
   differs between arms.

OUTPUT  D:\\retrain\\  metrics.csv and per-window scores
=============================================================================
"""
from pathlib import Path
import sys, time, json, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd

SHARDS = Path(r"D:\xcohort_full")
OUT = Path(r"D:\retrain"); (OUT / "scores").mkdir(parents=True, exist_ok=True)

WIN_S, FS = 4.0, 256.0
LEAD_S = 120.0
EPOCHS, BATCH, LR = 14, 128, 1e-3
VAL_FRAC = 0.10
SEEDS_CAUSAL = [1234]
SEEDS_ARCH = [1234, 3456, 5678, 7890, 9012]
CAUSAL_MODELS = ["EEGNet", "ShallowFBCSPNet", "ATCNet", "SPARCNet"]
MISSING_MODELS = ["EEGTCNet", "SincShallowNet"]
MAX_TRAIN = 60_000          # the sweep's subsample size, kept for comparability

import torch, torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.model_selection import GroupKFold
try:
    import braindecode.models as M
except ImportError:
    sys.exit("pip install braindecode")

DEV = "cuda" if torch.cuda.is_available() else "cpu"
def log(m): print(m, flush=True)
log("device: %s%s" % (DEV, " / " + torch.cuda.get_device_name(0) if DEV == "cuda" else ""))


# ----------------------------------------------------------------- data
def load(causal):
    """Every window, normalised one of two ways.

    Because z-scoring is affine, applying causal statistics on top of the
    stored whole-recording z-score equals applying them to the raw signal:
    the recording-level mean and standard deviation cancel."""
    lead_n = int(LEAD_S / WIN_S)
    X, y, sub, coh = [], [], [], []
    for f in sorted(SHARDS.glob("*.npz")):
        if f.stem == "manifest":
            continue
        z = np.load(f, allow_pickle=True)
        if z["X"].size == 0:
            continue
        W = z["X"]
        key = "rec" if "rec" in z.files else "file"
        rc = z[key].astype(str); od = z["order"].astype(int)
        if causal:
            Wc = np.empty_like(W)
            for r in np.unique(rc):
                m = np.where(rc == r)[0]; m = m[np.argsort(od[m])]
                blk = W[m].astype(np.float32)
                ref = blk[:min(lead_n, len(blk))]
                mu = ref.mean((0, 2), keepdims=True)
                sd = ref.std((0, 2), keepdims=True) + 1e-6
                Wc[m] = ((blk - mu) / sd).astype(W.dtype)
            W = Wc
        X.append(W); y.append(z["y"].astype(int))
        sub.append(np.full(len(z["y"]), f.stem))
        coh.append(np.full(len(z["y"]), "chb" if f.stem.lower().startswith("chb")
                           else "siena"))
    return (np.concatenate(X), np.concatenate(y), np.concatenate(sub),
            np.concatenate(coh))


def build(name, n_ch=17, n_t=1024, sfreq=FS):
    cls = getattr(M, name, None)
    if cls is None:
        return None
    for kw in (dict(n_chans=n_ch, n_outputs=2, n_times=n_t, sfreq=sfreq),
               dict(n_chans=n_ch, n_outputs=2, n_times=n_t),
               dict(n_chans=n_ch, n_outputs=2,
                    input_window_seconds=n_t/sfreq, sfreq=sfreq)):
        try:
            m = cls(**kw)
            with torch.no_grad():
                o = m(torch.zeros(2, n_ch, n_t))
            if o.ndim == 3:
                m = nn.Sequential(m, nn.AdaptiveAvgPool1d(1), nn.Flatten())
            return m
        except Exception:
            continue
    return None


def subsample(idx, yv, seed):
    """Every positive, sixty negatives per recording, as the sweep used."""
    r = np.random.default_rng(seed)
    pos = idx[yv[idx] == 1]; neg = idx[yv[idx] == 0]
    n = min(len(neg), max(1, MAX_TRAIN - len(pos)))
    return np.concatenate([pos, r.choice(neg, n, replace=False)])


def train_eval(Xa, ya, tr, te, name, seed):
    torch.manual_seed(seed); np.random.seed(seed)
    tr = subsample(tr, ya, seed)
    r = np.random.default_rng(seed)
    perm = r.permutation(len(tr))
    nval = max(1, int(len(tr) * VAL_FRAC))
    val, fit = tr[perm[:nval]], tr[perm[nval:]]

    model = build(name)
    if model is None:
        return None
    model = model.to(DEV)
    w = torch.tensor([1.0, max(1.0, (ya[fit] == 0).sum() / max((ya[fit] == 1).sum(), 1))],
                     dtype=torch.float32, device=DEV)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    lossf = nn.CrossEntropyLoss(weight=w)
    ds = TensorDataset(torch.from_numpy(Xa[fit].astype(np.float32)),
                       torch.from_numpy(ya[fit]).long())
    dl = DataLoader(ds, batch_size=BATCH, shuffle=True, drop_last=False)
    Xv = torch.from_numpy(Xa[val].astype(np.float32))
    best, best_state, patience = -1, None, 0
    for ep in range(EPOCHS):
        model.train()
        for xb, yb in dl:
            opt.zero_grad()
            loss = lossf(model(xb.to(DEV)), yb.to(DEV))
            loss.backward(); opt.step()
        model.eval()
        with torch.no_grad():
            sv = []
            for i in range(0, len(Xv), 512):
                sv.append(torch.softmax(model(Xv[i:i+512].to(DEV)).float(), 1)[:, 1].cpu())
            sv = torch.cat(sv).numpy()
        a = roc_auc_score(ya[val], sv) if len(np.unique(ya[val])) > 1 else 0.5
        if a > best:
            best, best_state, patience = a, {k: v.detach().cpu().clone()
                                             for k, v in model.state_dict().items()}, 0
        else:
            patience += 1
            if patience >= 3:
                break
    if best_state:
        model.load_state_dict(best_state)
    model.eval()
    s = []
    with torch.no_grad():
        for i in range(0, len(te), 512):
            xb = torch.from_numpy(Xa[te[i:i+512]].astype(np.float32)).to(DEV)
            s.append(torch.softmax(model(xb).float(), 1)[:, 1].cpu().numpy())
    del model
    if DEV == "cuda":
        torch.cuda.empty_cache()
    s = np.concatenate(s)
    prev = float(ya[te].mean()); ap = average_precision_score(ya[te], s)
    return s, dict(auroc=float(roc_auc_score(ya[te], s)), auprc=float(ap),
                   lift=float(ap/prev), prevalence=prev, n=int(len(te)),
                   epochs=ep+1, val_auroc=float(best))


def run(models, seeds, causal, tag):
    log("\n" + "=" * 66)
    log("%s  (normalisation: %s)" % (tag, "first 120 s" if causal else "whole recording"))
    log("=" * 66)
    Xa, ya, sub, coh = load(causal)
    patient = np.where(sub == "chb21", "chb01", sub)
    CHB = np.where(coh == "chb")[0]; SIE = np.where(coh == "siena")[0]
    log("  %d windows, %d positive" % (len(ya), ya.sum()))
    jobs = []
    folds = list(GroupKFold(5).split(CHB, ya[CHB], patient[CHB]))
    for i, (tr_i, te_i) in enumerate(folds):
        jobs.append(("S2", "fold%d" % i, CHB[tr_i], CHB[te_i]))
    jobs.append(("S3", "chb2siena", CHB, SIE))
    jobs.append(("S3", "siena2chb", SIE, CHB))

    rows, t0 = [], time.time()
    for name in models:
        for seed in seeds:
            for setting, fold, tr, te in jobs:
                rid = "%s_%s_%s_s%d_%s" % (name, setting, fold, seed, tag)
                f = OUT / "scores" / (rid + ".npz")
                if f.exists():
                    continue
                if len(np.unique(ya[te])) < 2:
                    continue
                r = train_eval(Xa, ya, tr, te, name, seed)
                if r is None:
                    log("  cannot build %s" % name); break
                s, m = r
                np.savez_compressed(f, score=s.astype(np.float32),
                                    label=ya[te].astype(np.int8), subject=sub[te])
                m.update(model=name, setting=setting, fold=fold, seed=seed,
                         normalisation="causal" if causal else "whole", run=tag)
                rows.append(m)
                pd.DataFrame([m]).to_csv(OUT / "metrics.csv", mode="a",
                    header=not (OUT / "metrics.csv").exists(), index=False)
                log("  %-38s AUROC %.3f  (%d epochs, %.1f min)"
                    % (rid, m["auroc"], m["epochs"], (time.time()-t0)/60))
    del Xa
    return pd.DataFrame(rows)


def report_causal(d):
    if d.empty:
        return
    log("\n" + "#" * 66)
    log("THE LEARNED ARM UNDER CAUSAL NORMALISATION")
    log("#" * 66)
    s2 = d[d.setting == "S2"].auroc.mean()
    s3 = d[d.setting == "S3"].auroc.mean()
    log("  causal:  S2 %.3f   S3 %.3f   drop %.3f" % (s2, s3, s2 - s3))
    log("  whole:   S2 0.949   S3 0.843   drop 0.106   (from refit.py)")
    log("\n  handcrafted under the same two rules:")
    log("    whole   S2 0.801  S3 0.788   drop 0.013")
    log("    causal  S2 0.781  S3 0.701   drop 0.080")
    log("\n  what to read: if the learned arm loses more at the cohort boundary")
    log("  than at the patient boundary, as the handcrafted arm does, the")
    log("  paper's ordering is reinforced. If it does not, the comparison")
    log("  between arms is conditional on the normalisation and must say so.")


def report_seeds(d):
    if d.empty:
        return
    log("\n" + "#" * 66)
    log("THE TWO ARCHITECTURES THAT WERE NEVER RERUN")
    log("#" * 66)
    log(d.pivot_table(index="model", columns="setting", values="auroc").round(3).to_string())
    log("\n  the single-seed sweep gave, for these two:")
    log("    EEGTCNet        S1 0.823  S2 0.875  S3 0.865")
    log("    SincShallowNet  S1 0.822  S2 0.881  S3 0.831")
    log("  both with S1 below S2, which cannot be a real ordering if S1 is the")
    log("  easier setting. This run covers S2 and S3 only, so it does not")
    log("  resolve that directly; S1 needs the within-patient split, which is")
    log("  in refit.py and would need these two architectures trained for it.")


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "both"
    t0 = time.time()
    if what in ("both", "causal"):
        d = run(CAUSAL_MODELS, SEEDS_CAUSAL, True, "causal")
        report_causal(d)
    if what in ("both", "seeds"):
        d = run(MISSING_MODELS, SEEDS_ARCH, False, "seeds")
        report_seeds(d)
    log("\n%.1f min | results in %s" % ((time.time() - t0) / 60, OUT))
