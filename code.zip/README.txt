ANALYSIS CODE
=============

Every script the paper's numbers come from. Python 3, and between them they
need: numpy, scipy, pandas, scikit-learn, matplotlib, mne, neurodsp,
specparam (or the older fooof), torch and braindecode.

    pip install numpy scipy pandas scikit-learn matplotlib mne neurodsp \
                specparam torch braindecode

PATHS

Each script carries its input and output paths at the top, as absolute
Windows paths from the machine the work was done on. Change those before
running anything; nothing is read from a config file or an environment
variable.

ORDER

These were run in this order, and later stages consume earlier ones.

  1  fix_labels.py diagnose       print what the Siena annotation files
                                  contain, so the parser is fixed from
                                  evidence rather than from a guess
     fix_labels.py rebuild        write the corrected annotations

  2  rerun_siena.py               rebuild Siena from those labels and rerun
                                  everything that tests on it. Seven stages
                                  (labels, shards, feats, handcrafted,
                                  learned, causal, report), each writing a
                                  marker so an interrupted run resumes.
                                  About six hours, three of them on a GPU.

     resume.py                    run this after an interruption and before
                                  rerun_siena.py. It opens every artefact,
                                  deletes the ones that will not load, and
                                  clears markers left by stages that only
                                  partly finished.

  3  refit.py                     GPU. Rescores the within-patient runs on
                                  the held-out 30 per cent rather than the
                                  whole shard, which is where a leak was,
                                  and reconstructs the cross-patient folds
                                  so they can be scored on continuous data.

  4  analysis.py                  CPU. The boundary comparison with one
                                  variable changing at a time, the blocked
                                  permutation test, the recording-context
                                  control on the full feature arm, a
                                  gradient-boosted baseline, and the event
                                  curves on a dense threshold grid.

  5  normalisation2.py            CPU. Causal normalisation for both
                                  feature arms and both boundaries.

  6  retrain.py                   GPU. The learned arm retrained under
                                  causal normalisation, and the two
                                  architectures that were never rerun with
                                  multiple seeds.

  7  recompute_all.py             CPU. Every figure the paper quotes, from
                                  one pass, with an assertion that expected
                                  calibration error cannot fall below the
                                  gap between mean predicted probability
                                  and observed rate.

  8  make_figs.py                 Figures 1, 3, 5, 6, 7 and 9 of the paper
                                  (F1, F3, F5, F16, F17, F18 by filename).
                                  Numbers are written in literally rather
                                  than read from disk, so a figure cannot
                                  drift away from the manuscript silently.

  verify.py                       Independent checks: Siena seizure counts
                                  against the per-subject information file,
                                  the PN00-3 timestamp against the
                                  recording length, the montage against the
                                  CHB-MIT summary, and the feature probes
                                  under recording-grouped folds.

EARLIER STAGES, KEPT FOR PROVENANCE

  sensitivity.py, fix_table1.py, table_numbers.py, collect.py,
  make_f2.py, fix_figures.py

  These produced intermediate results during the work. Some of their
  numbers were superseded; where that happened the paper says so. They are
  included because a reader checking how a figure came about should be able
  to follow the whole path, not only its last step.

TWO THINGS WORTH KNOWING BEFORE RUNNING ANY OF IT

  The feature vector must match the cached CHB-MIT matrices column for
  column. An earlier version of the Siena extraction used different Welch
  parameters and grouped bands across channels rather than channels across
  bands; the cross-patient figures were unaffected, being CHB-MIT on both
  sides, while the cross-cohort figures fell below chance. rerun_siena.py
  now checks the layout before it computes anything and stops on a
  mismatch.

  The spectral parameterisation is the slow part: roughly two million
  model fits for Siena alone. rerun_siena.py runs it across eight
  processes, which takes about twenty minutes; single-threaded it takes
  several hours.
