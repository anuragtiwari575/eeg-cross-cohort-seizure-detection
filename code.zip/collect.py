"""
=============================================================================
COLLECT EVERYTHING THE PAPER NEEDS INTO ONE FOLDER
=============================================================================
    python -u collect.py

Gathers main.tex, references.bib and every figure into D:\\paper, ready to
compile or to upload to Overleaf as a project.

The figures are written by several scripts into several directories, and
after the ablation some of them exist in more than one place with different
contents. This takes the most recently written copy of each and reports
where each came from, so a stale figure cannot be picked up silently.
=============================================================================
"""
from pathlib import Path
import shutil, re, sys, time

DEST = Path(r"D:\paper")
FIGD = DEST / "figures"
FIGD.mkdir(parents=True, exist_ok=True)

SOURCES = [
    Path(r"D:\figures"),
    Path(r"D:\native_inference\figures"),
    Path(r"D:\handcrafted_event\figures"),
    Path(r"D:\ablation\figures"),
    Path(r"C:\Users\Anurag Tiwari\Downloads\results\analysis_output\figures"),
]
TEX = [Path(r"C:\Users\Anurag Tiwari\Downloads\main.tex"),
       Path(r"D:\paper\main.tex"), Path(r"D:\eeg_project\main.tex")]
BIB = [Path(r"C:\Users\Anurag Tiwari\Downloads\references.bib"),
       Path(r"D:\paper\references.bib"), Path(r"D:\eeg_project\references.bib")]


def newest(paths):
    paths = [p for p in paths if p.exists()]
    return max(paths, key=lambda p: p.stat().st_mtime) if paths else None


# ---- tex and bib ----
for cands, name in ((TEX, "main.tex"), (BIB, "references.bib")):
    src = newest(cands)
    if src is None:
        print("MISSING %s -- looked in:" % name)
        for c in cands:
            print("    ", c)
        continue
    if src.resolve() != (DEST / name).resolve():
        shutil.copy(src, DEST / name)
    print("%-16s <- %s  (%s)"
          % (name, src, time.strftime("%d %b %H:%M", time.localtime(src.stat().st_mtime))))

# ---- figures ----
found = {}
for d in SOURCES:
    if not d.exists():
        continue
    for f in d.glob("*.pdf"):
        cur = found.get(f.name)
        if cur is None or f.stat().st_mtime > cur.stat().st_mtime:
            found[f.name] = f

print("\nfigures:")
for name in sorted(found, key=lambda s: int(re.match(r"F(\d+)", s).group(1))
                   if re.match(r"F(\d+)", s) else 99):
    src = found[name]
    shutil.copy(src, FIGD / name)
    print("  %-28s <- %-34s %s"
          % (name, src.parent,
             time.strftime("%d %b %H:%M", time.localtime(src.stat().st_mtime))))

# ---- check against what the tex asks for ----
tex = (DEST / "main.tex")
if tex.exists():
    t = tex.read_text(encoding="utf-8", errors="ignore")
    want = sorted(set(re.findall(r'\\includegraphics\[[^\]]*\]\{figures/([^}]+)\}', t)))
    have = {p.name for p in FIGD.glob("*.pdf")}
    miss = [w for w in want if w not in have]
    extra = [h for h in sorted(have) if h not in want]
    print("\nthe tex asks for %d figures; %d present" % (len(want), len(want) - len(miss)))
    if miss:
        print("  MISSING:", miss)
    if extra:
        print("  present but unused:", extra)
    cited = {k.strip() for g in re.findall(r'\\citep?\{([^}]*)\}', t) for k in g.split(',')}
    items = set(re.findall(r'\\bibitem\{([^}]+)\}', t))
    print("citations: %d cited, %d bibitems, %s"
          % (len(cited), len(items),
             "all resolve" if cited == items else "MISMATCH %s" % sorted(cited ^ items)))

print("\n%s is ready." % DEST)
print("compile:  cd /d %s  &&  pdflatex main  &&  pdflatex main" % DEST)
print("overleaf: zip main.tex, references.bib and figures\\, upload as a project")
