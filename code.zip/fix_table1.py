"""
=============================================================================
CORRECT THE NATIVE-PREVALENCE FILTER
=============================================================================
    python -u fix_table1.py

Recomputes Table 1, the fold counts and the headline from the ablation CSV
that already exists. Nothing is refitted.

THE PROBLEM

The ablation writes one row per (setting, fold, feature set, prevalence).
Native rows were selected by testing whether the target prevalence equalled
the achieved prevalence. That is true of a native row by construction, but
it is also true of a resampled row whenever the resampling hit its target
exactly, which it does for the 7.36% rows. Two such rows were therefore
counted as native, which is why the leave-one-out fold counts came to 26
where CHB-MIT has 24 recording sets.

The fix is to select native rows by what they are rather than by a numerical
coincidence: a row is native if its target prevalence is not one of the
resampling targets.

WRITES  table1.csv, fold_counts.csv, headline.txt in the same results folder
        (the originals are left in place with a .super suffix)
=============================================================================
"""
from pathlib import Path
import sys
import numpy as np, pandas as pd

RES = Path(r"D:\ablation\results")
# Every prevalence the ablation resamples to. An earlier version of this
# script listed only 0.0736, so rows at 50, 25, 10, 5 and 1 per cent were
# also counted as native. AUROC is prevalence-invariant and was therefore
# unaffected, but AUPRC and lift were averaged across the whole sweep, which
# is why the lift figures implied a base rate that matched no test set.
RESAMPLE_TARGETS = [0.50, 0.25, 0.10, 0.0736, 0.05, 0.01]
LEARNED_NATIVE, LEARNED_MATCHED = 0.843, 0.853

f = RES / "ablation.csv"
if not f.exists():
    sys.exit("%s not found" % f)
d = pd.read_csv(f)

# a row is native unless its target is one of the resampling targets
is_target = np.zeros(len(d), bool)
for t in RESAMPLE_TARGETS:
    is_target |= np.isclose(d.target_prev, t)
nat = d[~is_target].copy()
mat = d[is_target].copy()

print("rows: %d total, %d native, %d resampled" % (len(d), len(nat), len(mat)))

# a native row is the one that kept every window, so it should be the
# largest n in its group; check rather than assume
chk = nat.groupby(["setting", "fold", "features"]).size()
if (chk > 1).any():
    print("WARNING: %d groups still have more than one native row"
          % int((chk > 1).sum()))
else:
    print("one native row per (setting, fold, feature set): correct")
print("base rates implied by lift:")
for s, g in nat.groupby("setting"):
    br = (g.auprc / g.lift)
    print("   %-10s %.5f to %.5f  (prevalence column: %.5f to %.5f)"
          % (s, br.min(), br.max(), g.prevalence.min(), g.prevalence.max()))
for s, g in nat.groupby("setting"):
    print("  %-10s %d folds per feature set"
          % (s, g.groupby("features").size().iloc[0]))

# ----------------------------------------------------------------- Table 1
tab = nat.pivot_table(index="features", columns="setting",
                      values="auroc", aggfunc="mean")
cols = [c for c in ("LOO-CHB", "LOO-Siena", "S3-fwd", "S3-rev") if c in tab]
tab = tab[cols]
nfeat = nat.groupby("features").n_features.first()
tab.insert(0, "n", nfeat)
tab.to_csv(RES / "table1.csv")
print("\n=== TABLE 1, native prevalence ===")
print(tab.round(3).to_string())

print("\n=== lift over chance, cross-cohort ===")
lt = nat[nat.setting.str.startswith("S3")].groupby("features").lift.mean()
print(lt.round(2).to_string())

# ----------------------------------------------------------------- folds
rows = []
print("\n=== leave-one-out folds below the cross-cohort transfer ===")
for name in tab.index:
    loo = nat[(nat.setting == "LOO-CHB") & (nat.features == name)]
    for setting, lab in (("S3-fwd", "chb->siena"), ("S3-rev", "siena->chb")):
        x = nat[(nat.setting == setting) & (nat.features == name)]
        if loo.empty or x.empty:
            continue
        cross = float(x.auroc.mean())
        below = int((loo.auroc < cross).sum())
        rows.append(dict(features=name, direction=lab, cross=round(cross, 3),
                         n_below=below, n_folds=len(loo)))
        print("   %-18s %-12s cross %.3f   %2d of %d folds worse"
              % (name, lab, cross, below, len(loo)))
pd.DataFrame(rows).to_csv(RES / "fold_counts.csv", index=False)

# ----------------------------------------------------------------- headline
s3 = nat[nat.setting.str.startswith("S3")].groupby("features").auroc.mean()
m3 = mat[mat.setting.str.startswith("S3")].groupby("features").auroc.mean()
best = s3.idxmax()
gap_n = LEARNED_NATIVE - s3[best]
gap_m = LEARNED_MATCHED - m3.get(best, np.nan)
band = ("above 0.10" if gap_n > 0.10 else
        "between 0.05 and 0.10" if gap_n >= 0.05 else "below 0.05")

lines = [
    "best handcrafted set: %s" % best,
    "  native   handcrafted %.3f vs learned %.3f -> gap %.3f"
    % (s3[best], LEARNED_NATIVE, gap_n),
    "  matched  handcrafted %.3f vs learned %.3f -> gap %.3f"
    % (m3.get(best, np.nan), LEARNED_MATCHED, gap_m),
    "  gap is %s" % band,
    "",
    "over the spectral-only baseline (cross-cohort, native):",
    "  %s %.3f -> %s %.3f   (+%.3f)"
    % ("E A+B (current)", s3.get("E A+B (current)", np.nan), best, s3[best],
       s3[best] - s3.get("E A+B (current)", np.nan)),
    "  C temporal alone: %.3f" % s3.get("C temporal", np.nan),
]
print("\n=== HEADLINE ===")
print("\n".join(lines))
(RES / "headline.txt").write_text("\n".join(lines), encoding="utf-8")

# ----------------------------------------------------------------- events
ev = RES / "event_level.csv"
if ev.exists():
    E = pd.read_csv(ev)
    print("\n=== event level, cross-cohort only ===")
    print("The leave-one-out settings hold too few seizures for this to mean")
    print("anything: 40 h and 10 h of recording give three or four events, so")
    print("sensitivity is quantised to 0.33 or 0.50 and is not reported.")
    for setting in ("S3-fwd", "S3-rev"):
        sub = E[E.setting == setting]
        if sub.empty:
            continue
        print("--- %s (%.0f h, %d events) ---"
              % (setting, sub.hours.mean(), sub.n_events.max()))
        for fam in sorted(sub.features.unique()):
            g = sub[sub.features == fam]
            out = []
            for tgt in (0.5, 1.0, 2.0, 5.0):
                ok = g[g.fa_per_hour <= tgt]
                out.append("%.1f: %.3f" % (tgt, ok.sensitivity.max()
                                           if len(ok) else 0.0))
            print("   %-4s %s" % (fam, "   ".join(out)))

print("\nwritten to %s" % RES)
