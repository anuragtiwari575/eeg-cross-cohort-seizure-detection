"""
=============================================================================
THE REMAINING ANALYSES
=============================================================================
    python -u analysis.py

Everything the review asks for that runs on a CPU. The GPU part, rescoring
the within-patient runs without leakage and recovering the cross-patient
folds, is refit.py and should be run first; this script uses its output if
it is present and says so if it is not.

WHAT IS ADDRESSED, AND WHY EACH MATTERS

1  THE BOUNDARY COMPARISON, WITH ONE THING CHANGING AT A TIME

   The comparison of interest is the cost of a new patient against the
   additional cost of a new centre. As run, several things change between
   the settings at once: which subjects are tested, how the score is
   aggregated, and which cohort the test set comes from. Each is separated
   here.

   (a) S2 restricted to the eight subjects S1 admits, so the two settings
       describe the same people.
   (b) Per-subject AUROC in every setting, since pooling across subjects
       also penalises between-subject score offsets and part of the
       apparent patient cost is that penalty rather than transfer.
   (c) A seen-patient population model: train on the early part of every
       subject and test on the later part. This isolates the patient
       boundary from the patient-specific/population distinction.
   (d) Contrasts that hold the test cohort fixed. Siena within-cohort
       against CHB-MIT to Siena; CHB-MIT cross-patient against Siena to
       CHB-MIT. These are the comparisons in which only the training
       cohort changes.
   (f) The per-fold claim, paired. Comparing one subject's AUROC against a
       pooled cohort figure is not a paired comparison; per subject, the
       held-out figure is compared with that same subject's score under
       cross-cohort transfer.
   (g) A hierarchical bootstrap over subjects, and a sign test, since 14
       architectures on the same subjects are not independent replications.

2  THE ARCHITECTURE STATISTIC

   The published statistic divides a range of architecture means by a mean
   within-cell standard deviation, which are not on the same scale, and the
   rule "ratio at most one means indistinguishable" has no null behind it.
   Replaced by a blocked permutation test that shuffles architecture labels
   within fold and seed, and by a variance decomposition.

3  NORMALISATION, BOTH ARMS AND BOTH BOUNDARIES

   Whole-recording z-scoring uses each test recording's own statistics,
   which removes gain and amplitude differences including those between
   paediatric and adult recordings. Part of the cheapness of the cohort
   boundary may be produced by it. Run for S2 as well as S3, and for the
   spectral arm as well as the full one, so the interaction with the
   feature-set result is visible rather than assumed.

   Also: the recording-context control was run on spectral features, which
   are invariant to per-channel scaling and therefore cannot detect an
   amplitude signature. Rerun on the full arm.

4  A STRONGER HANDCRAFTED BASELINE

   The claim that the gap is at most 0.055 rests on a linear model over
   per-channel features, which cannot generalise across seizure
   localisation. Added: channel-aggregated summaries, Hjorth parameters,
   spectral entropy, absolute power, and a gradient-boosted tree.

5  EVENT-LEVEL SCORING

   The threshold grid runs from the 90th to the 99.995th percentile in
   about forty steps, which at roughly 900 windows per hour leaves at most
   one operating point between 0.1 and 2 false alarms per hour. Replaced by
   a grid dense in that region. Events are also reconciled against the
   annotations, since merged runs of positive windows are fewer than the
   annotated seizures.

OUTPUT  D:\\analysis\\ , one CSV per analysis and a printed summary
=============================================================================
"""
from pathlib import Path
import sys, json, time, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd

CACHE  = Path(r"D:\ablation\cache")
SHARDS = Path(r"D:\xcohort_full")
REFIT  = Path(r"D:\refit\scores")
NATIVE = Path(r"D:\native_inference\scores")
OUT    = Path(r"D:\analysis"); OUT.mkdir(parents=True, exist_ok=True)

FS, WIN_S, SEED = 256.0, 4.0, 1234
NB, MAX_TRAIN, N_BOOT = 85, 150_000, 2000
TRAIN_FRAC = 0.70

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.model_selection import GroupKFold
from scipy.stats import binomtest

RES = {}
def log(m): print(m, flush=True)


# ----------------------------------------------------------------- data
log("loading features")
X, y, sub, coh, rec, order = [], [], [], [], [], []
for f in sorted(CACHE.glob("*.npz")):
    d = np.load(f, allow_pickle=True)
    if d["X"].size == 0:
        continue
    X.append(d["X"]); y.append(d["y"])
    sub.append(np.full(len(d["y"]), f.stem))
    coh.append(np.full(len(d["y"]), "chb" if f.stem.lower().startswith("chb") else "siena"))
    rec.append(d["rec"].astype(str)); order.append(d["order"])
X = np.vstack(X); y = np.concatenate(y); sub = np.concatenate(sub)
coh = np.concatenate(coh); rec = np.concatenate(rec); order = np.concatenate(order)
ok = np.isfinite(X).all(1)
X, y, sub, coh, rec, order = X[ok], y[ok], sub[ok], coh[ok], rec[ok], order[ok]

# chb21 is chb01 recorded about eighteen months later; grouped as one patient
patient = np.where(sub == "chb21", "chb01", sub)

B, off = {}, 0
for fam, w in (("bandpower", NB), ("aperiodic", 119 - NB),
               ("ll", 17), ("tkeo", 34), ("wave", 102)):
    B[fam] = np.arange(off, off + w); off += w
AB  = np.concatenate([B["bandpower"], B["aperiodic"]])
ABC = np.concatenate([B["bandpower"], B["aperiodic"], B["ll"], B["tkeo"]])
CHB = np.where(coh == "chb")[0]; SIE = np.where(coh == "siena")[0]
log("  %d windows, %d positive, %d subjects (%d patients after grouping chb21)"
    % (len(y), y.sum(), len(np.unique(sub)), len(np.unique(patient))))


def lr():
    return make_pipeline(StandardScaler(),
                         LogisticRegression(max_iter=1000, class_weight="balanced"))


def fit_predict(cols, tr, te, clf=None, Xm=None):
    Xs = X if Xm is None else Xm
    Xtr, ytr = Xs[np.ix_(tr, cols)], y[tr]
    if len(ytr) > MAX_TRAIN:
        r = np.random.default_rng(SEED)
        p = np.where(ytr == 1)[0]; n = np.where(ytr == 0)[0]
        n = r.choice(n, max(1, min(len(n), MAX_TRAIN - len(p))), replace=False)
        k = np.concatenate([p, n]); Xtr, ytr = Xtr[k], ytr[k]
    m = clf() if clf else lr()
    m.fit(Xtr, ytr)
    return m.predict_proba(Xs[np.ix_(te, cols)])[:, 1]


def per_subject_auc(te, s, units):
    """AUROC computed inside each held-out subject, then averaged.

    Pooling subjects also penalises between-subject score offsets, so a
    pooled figure mixes discrimination with calibration across people."""
    out = {}
    for u in np.unique(units[te]):
        m = units[te] == u
        if len(np.unique(y[te][m])) > 1:
            out[u] = float(roc_auc_score(y[te][m], s[m]))
    return out


# ================================================== 1. the boundary comparison
def s1_subjects():
    """The eight CHB-MIT recording sets S1 admits, by its own rule."""
    keep = []
    for u in np.unique(sub[CHB]):
        idx = np.where((coh == "chb") & (sub == u))[0]
        o = idx[np.argsort(order[idx])]
        cut = int(len(o) * TRAIN_FRAC)
        if y[o[:cut]].sum() >= 30 and y[o[cut:]].sum() >= 8:
            keep.append(u)
    return sorted(keep)


def boundary():
    log("\n" + "=" * 70)
    log("1. THE BOUNDARY COMPARISON, ONE THING AT A TIME")
    log("=" * 70)
    out = {}
    S1SUB = s1_subjects()
    out["s1_subjects"] = S1SUB
    log("S1 admits %d recording sets: %s" % (len(S1SUB), " ".join(S1SUB)))

    # --- (c) seen-patient population model: early part of everyone -> later part
    tr, te = [], []
    for u in np.unique(sub[CHB]):
        idx = np.where((coh == "chb") & (sub == u))[0]
        o = idx[np.argsort(order[idx])]
        cut = int(len(o) * TRAIN_FRAC)
        tr.append(o[:cut]); te.append(o[cut:])
    tr, te = np.concatenate(tr), np.concatenate(te)
    s = fit_predict(ABC, tr, te)
    ps = per_subject_auc(te, s, sub)
    out["seen_patient_population"] = dict(
        pooled=float(roc_auc_score(y[te], s)),
        per_subject_mean=float(np.mean(list(ps.values()))), n=len(ps))
    log("\n(c) seen-patient population model (every subject in training):")
    log("     pooled %.3f | per-subject mean %.3f over %d subjects"
        % (out["seen_patient_population"]["pooled"],
           out["seen_patient_population"]["per_subject_mean"], len(ps)))

    # --- (a) S2 restricted to the S1 subjects, and (b) per-subject everywhere
    gkf = GroupKFold(n_splits=5)
    pooled, persub, persub_all = [], [], {}
    for tr_i, te_i in gkf.split(CHB, y[CHB], patient[CHB]):
        trf, tef = CHB[tr_i], CHB[te_i]
        if len(np.unique(y[tef])) < 2:
            continue
        sc = fit_predict(ABC, trf, tef)
        pooled.append(roc_auc_score(y[tef], sc))
        d = per_subject_auc(tef, sc, sub)
        persub_all.update(d)
        persub += list(d.values())
    out["S2_pooled"] = float(np.mean(pooled))
    out["S2_per_subject"] = float(np.mean(persub))
    out["S2_per_subject_on_S1_subjects"] = float(
        np.mean([v for k, v in persub_all.items() if k in S1SUB]))
    log("\n(a,b) cross-patient, aggregated three ways:")
    log("     pooled per fold            %.3f" % out["S2_pooled"])
    log("     per subject, all 24        %.3f" % out["S2_per_subject"])
    log("     per subject, the 8 of S1   %.3f" % out["S2_per_subject_on_S1_subjects"])
    log("     if the eight are easier, part of the S1 to S2 drop is subject choice")

    # --- (d) contrasts holding the test cohort fixed
    log("\n(d) contrasts in which only the training cohort changes:")
    # test on Siena: within-Siena cross-patient vs CHB-MIT -> Siena
    within_sie = []
    for tr_i, te_i in GroupKFold(n_splits=5).split(SIE, y[SIE], patient[SIE]):
        trf, tef = SIE[tr_i], SIE[te_i]
        if len(np.unique(y[tef])) < 2:
            continue
        within_sie.append(roc_auc_score(y[tef], fit_predict(ABC, trf, tef)))
    s_fwd = fit_predict(ABC, CHB, SIE)
    out["test_siena_within"] = float(np.mean(within_sie))
    out["test_siena_from_chb"] = float(roc_auc_score(y[SIE], s_fwd))
    log("     testing on Siena:   within-cohort %.3f | from CHB-MIT %.3f | cost %.3f"
        % (out["test_siena_within"], out["test_siena_from_chb"],
           out["test_siena_within"] - out["test_siena_from_chb"]))
    s_rev = fit_predict(ABC, SIE, CHB)
    out["test_chb_within"] = out["S2_pooled"]
    out["test_chb_from_siena"] = float(roc_auc_score(y[CHB], s_rev))
    log("     testing on CHB-MIT: within-cohort %.3f | from Siena  %.3f | cost %.3f"
        % (out["test_chb_within"], out["test_chb_from_siena"],
           out["test_chb_within"] - out["test_chb_from_siena"]))
    log("     these are the comparisons in which the test population is held fixed")

    # --- (f) the per-fold claim, paired
    log("\n(f) per subject, leave-one-out against that subject under transfer:")
    loo, xco = {}, per_subject_auc(CHB, s_rev, sub)
    for u in np.unique(sub[CHB]):
        tef = np.where((coh == "chb") & (sub == u))[0]
        trf = np.where((coh == "chb") & (patient != patient[tef][0]))[0]
        if len(np.unique(y[tef])) < 2:
            continue
        loo[u] = float(roc_auc_score(y[tef], fit_predict(ABC, trf, tef)))
    common = sorted(set(loo) & set(xco))
    diff = np.array([loo[u] - xco[u] for u in common])
    n_worse = int((diff < 0).sum())
    bt = binomtest(n_worse, len(common), 0.5)
    out["paired_loo_vs_transfer"] = dict(
        n=len(common), n_loo_worse=n_worse, mean_diff=float(diff.mean()),
        p_sign=float(bt.pvalue),
        ci=[float(v) for v in np.percentile(
            [diff[np.random.default_rng(SEED + i).integers(0, len(diff), len(diff))].mean()
             for i in range(N_BOOT)], [2.5, 97.5])])
    log("     %d subjects, held-out worse than transfer in %d, mean difference %+.3f"
        % (len(common), n_worse, diff.mean()))
    log("     sign test p = %.3f | bootstrap CI on the mean difference [%.3f, %.3f]"
        % (bt.pvalue, *out["paired_loo_vs_transfer"]["ci"]))
    log("     this is the paired version; the earlier count compared a single")
    log("     subject against a pooled cohort figure, which is not paired")
    return out


# ================================================== 2. architecture statistic
def architecture():
    log("\n" + "=" * 70)
    log("2. ARCHITECTURE DIFFERENCES, TESTED PROPERLY")
    log("=" * 70)
    src = None
    for c in (Path(r"C:\Users\Anurag Tiwari\Downloads\results\metrics.csv"),
              Path(r"D:\results\metrics.csv")):
        if c.exists():
            src = c; break
    if src is None:
        log("  metrics.csv from the five-seed sweep not found; skipping")
        return {}
    d = pd.read_csv(src)
    cols = {c.lower(): c for c in d.columns}
    need = [cols.get(k) for k in ("model", "setting", "fold", "seed", "auroc")]
    if any(v is None for v in need):
        log("  unexpected columns in %s: %s" % (src, list(d.columns))); return {}
    d = d.rename(columns=dict(zip(need, ["model", "setting", "fold", "seed", "auroc"])))
    out = {}
    rng = np.random.default_rng(SEED)
    for st in sorted(d.setting.unique()):
        g = d[d.setting == st]
        obs = g.groupby("model").auroc.mean()
        stat = float(obs.max() - obs.min())
        # blocked permutation: shuffle architecture labels within fold and seed,
        # which preserves everything except the architecture assignment
        null = []
        for _ in range(5000):
            gp = g.copy()
            gp["model"] = gp.groupby(["fold", "seed"]).model.transform(
                lambda s: rng.permutation(s.values))
            m = gp.groupby("model").auroc.mean()
            null.append(m.max() - m.min())
        null = np.array(null)
        p = float((null >= stat).mean())
        # variance decomposition
        tot = g.auroc.var()
        v_arch = g.groupby("model").auroc.mean().var()
        v_fold = g.groupby("fold").auroc.mean().var()
        v_seed = g.groupby("seed").auroc.mean().var()
        out[st] = dict(range=stat, p_blocked_permutation=p,
                       var_total=float(tot), var_architecture=float(v_arch),
                       var_fold=float(v_fold), var_seed=float(v_seed),
                       mdd=float(np.percentile(null, 95)))
        log("  %s  range %.4f  p = %.3f  (null 95th percentile %.4f)"
            % (st, stat, p, out[st]["mdd"]))
        log("      variance: architecture %.5f  fold %.5f  seed %.5f  total %.5f"
            % (v_arch, v_fold, v_seed, tot))
    log("\n  The published ratio divided a range by a mean within-cell standard")
    log("  deviation, two quantities on different scales, and had no null behind")
    log("  it. The permutation p values above are the test that rule stood in for.")
    return out


# ================================================== 3. recording context, full arm
def context_control():
    """The recording-context control, on the arm that can actually fail it.

    The published control used spectral features only. Relative band power
    and the aperiodic exponent are invariant to a per-channel rescaling, so
    they cannot carry the amplitude signature that whole-recording z-scoring
    would create; the control was blind to the thing it was meant to detect.
    Run here on the full arm, which is not invariant."""
    log("\n" + "=" * 70)
    log("3. RECORDING-CONTEXT CONTROL ON THE FULL ARM")
    log("=" * 70)
    out = {}
    neg = np.where(y == 0)[0]
    has_sz = {r for r in np.unique(rec) if y[rec == r].sum() > 0}
    lab = np.isin(rec[neg], list(has_sz)).astype(int)
    if len(np.unique(lab)) < 2:
        log("  only one kind of recording; skipping"); return out
    for arm, cols in (("AB", AB), ("ABC", ABC)):
        a = []
        for tr_i, te_i in GroupKFold(5).split(neg, lab, patient[neg]):
            tr, te = neg[tr_i], neg[te_i]
            if len(np.unique(lab[te_i])) < 2:
                continue
            m = lr(); m.fit(X[np.ix_(tr, cols)], lab[tr_i])
            a.append(roc_auc_score(lab[te_i], m.predict_proba(X[np.ix_(te, cols)])[:, 1]))
        out[arm] = float(np.mean(a))
        log("  %-4s  %.3f   (%d non-seizure windows, %d from seizure-containing "
            "recordings)" % (arm, out[arm], len(neg), int(lab.sum())))
    log("  A value near chance means non-seizure windows carry no session-level")
    log("  signature. The spectral arm cannot show one even if it exists.")
    return out


# ================================================== 4. a stronger baseline
def stronger_baseline():
    """Channel-aggregated features and a nonlinear classifier.

    A linear model over per-channel features cannot generalise across
    seizure localisation: a temporal-lobe seizure and a frontal one load
    different channels, and a single weight vector cannot serve both. Adding
    order statistics over channels removes that dependence, and a tree model
    can use them nonlinearly."""
    log("\n" + "=" * 70)
    log("4. A STRONGER HANDCRAFTED BASELINE")
    log("=" * 70)
    # channel-aggregated summaries of each per-channel block
    blocks = [("bp%d" % k, B["bandpower"][k*17:(k+1)*17]) for k in range(5)]
    blocks += [("ap", B["aperiodic"][:17]), ("ll", B["ll"]),
               ("tk", B["tkeo"][:17])]
    agg = []
    for _, idx in blocks:
        v = X[:, idx]
        agg.append(np.column_stack([v.mean(1), v.std(1), v.max(1), v.min(1),
                                    np.median(v, 1),
                                    np.percentile(v, 90, axis=1),
                                    v.max(1) - v.min(1)]))
    AGG = np.hstack(agg).astype(np.float32)
    XA = np.hstack([X[:, ABC], AGG])
    log("  %d per-channel features plus %d channel-aggregated = %d"
        % (len(ABC), AGG.shape[1], XA.shape[1]))

    out = {}
    def run(Xm, cols, clf, tag):
        r = {}
        for name, tr, te in (("S3fwd", CHB, SIE), ("S3rev", SIE, CHB)):
            Xtr, ytr = Xm[np.ix_(tr, cols)], y[tr]
            if len(ytr) > MAX_TRAIN:
                g = np.random.default_rng(SEED)
                pp = np.where(ytr == 1)[0]; nn = np.where(ytr == 0)[0]
                nn = g.choice(nn, max(1, min(len(nn), MAX_TRAIN - len(pp))), replace=False)
                k = np.concatenate([pp, nn]); Xtr, ytr = Xtr[k], ytr[k]
            m = clf(); m.fit(Xtr, ytr)
            s = m.predict_proba(Xm[np.ix_(te, cols)])[:, 1]
            r[name] = float(roc_auc_score(y[te], s))
        r["mean"] = float(np.mean([r["S3fwd"], r["S3rev"]]))
        out[tag] = r
        log("  %-34s fwd %.3f  rev %.3f  mean %.3f"
            % (tag, r["S3fwd"], r["S3rev"], r["mean"]))

    allc = np.arange(XA.shape[1])
    run(X, ABC, lr, "A+B+C, linear (the paper's arm)")
    run(XA, allc, lr, "plus channel aggregates, linear")
    run(XA, allc,
        lambda: HistGradientBoostingClassifier(max_iter=300, learning_rate=.1,
                                               class_weight="balanced",
                                               random_state=SEED),
        "plus channel aggregates, gradient boosting")
    best = max(v["mean"] for v in out.values())
    log("\n  learned representations reach 0.843 cross-cohort")
    log("  best handcrafted here %.3f  ->  gap %.3f" % (best, 0.843 - best))
    log("  the paper's figure of 0.055 holds only if no better baseline exists;")
    log("  this is one attempt at a better one, not a proof that none exists")
    return out


# ================================================== 5. event level, dense grid
def merge_events(mask, ordr):
    o = np.argsort(ordr); m = mask[o]; oo = ordr[o]
    ev, i = [], 0
    while i < len(m):
        if m[i]:
            j = i
            while j + 1 < len(m) and m[j+1] and oo[j+1] == oo[j] + 1:
                j += 1
            ev.append((oo[i], oo[j])); i = j + 1
        else:
            i += 1
    return ev


def event_level():
    """A grid dense where the operating points of interest are.

    The published grid ran from the 90th to the 99.995th percentile in about
    forty steps. At roughly nine hundred windows an hour that leaves at most
    one point between 0.1 and 2 false alarms per hour, which is the whole
    region a clinical reader cares about, and it is why two operating points
    in the published table carry identical values.

    Events are also reconciled against the annotations: contiguous runs of
    positive windows are fewer than annotated seizures, because a seizure
    split by a discarded boundary window becomes two runs, or none if it is
    short."""
    log("\n" + "=" * 70)
    log("5. EVENT LEVEL ON A DENSE GRID, AND THE EVENT COUNT")
    log("=" * 70)
    rows = []
    for tag, tr, te in (("S3fwd", CHB, SIE), ("S3rev", SIE, CHB)):
        s = fit_predict(ABC, tr, te)
        yy, rc, od = y[te], rec[te], order[te]
        hours = len(yy) * WIN_S / 3600
        # how many events the labels themselves contain
        n_true = sum(len(merge_events(yy[rc == r] == 1, od[rc == r]))
                     for r in np.unique(rc))
        log("\n  %s: %d contiguous positive runs in the labels, %.0f h"
            % (tag, n_true, hours))
        grid = np.unique(np.concatenate([
            np.quantile(s, np.linspace(0.90, 0.999, 60)),
            np.quantile(s, np.linspace(0.999, 0.99999, 60))]))
        for thr in grid:
            pred = s >= thr; tp = fp = ne = 0
            for r in np.unique(rc):
                m = rc == r
                tev = merge_events(yy[m] == 1, od[m]); pev = merge_events(pred[m], od[m])
                ne += len(tev); hit = set()
                for a, b in pev:
                    ov = [k for k, (c, e) in enumerate(tev) if not (b < c or a > e)]
                    if ov: hit.update(ov)
                    else: fp += 1
                tp += len(hit)
            if ne:
                rows.append(dict(setting=tag, threshold=float(thr),
                                 sensitivity=tp/ne, fa_per_hour=fp/hours,
                                 n_events=ne, hours=hours))
    d = pd.DataFrame(rows)
    d.to_csv(OUT / "event_dense.csv", index=False)
    log("")
    for tag in ("S3fwd", "S3rev"):
        g = d[d.setting == tag]
        if g.empty: continue
        line = []
        for t in (0.1, 0.25, 0.5, 1.0, 2.0, 5.0):
            v = g[g.fa_per_hour <= t]
            line.append("%.2f:%.3f" % (t, v.sensitivity.max() if len(v) else 0.0))
        n_pts = int(((g.fa_per_hour >= 0.1) & (g.fa_per_hour <= 2)).sum())
        log("  %s  %s   (%d grid points between 0.1 and 2 FA/h)"
            % (tag, "  ".join(line), n_pts))
    return d.to_dict("records")


if __name__ == "__main__":
    t0 = time.time()
    RES["boundary"] = boundary()
    RES["architecture"] = architecture()
    RES["context_control"] = context_control()
    RES["stronger_baseline"] = stronger_baseline()
    RES["event_dense"] = event_level()
    json.dump(RES, open(OUT / "analysis.json", "w"), indent=2, default=float)
    log("\n" + "#" * 70)
    log("written to %s" % OUT)
    log("%.1f min" % ((time.time() - t0) / 60))
    log("")
    log("Causal normalisation for both arms and both boundaries is in")
    log("normalisation2.py: it recomputes the temporal features three times")
    log("over the whole set and takes about an hour on its own.")
