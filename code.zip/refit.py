"""
=============================================================================
FIX THE WITHIN-PATIENT LEAKAGE AND RECOVER THE CROSS-PATIENT FOLDS
=============================================================================
    python -u refit.py

Two defects in the continuous-data inference, both in the scoring rather
than in the models.

1. WITHIN-PATIENT LEAKAGE

   infer_local.py scores every window of a subject's shard for S1. The S1
   models were trained on the first \\SI{70}{\\percent} of that subject in
   time, so about seventy per cent of the scored windows were in training.
   Everything derived from that is wrong and wrong in the flattering
   direction: the S1 row of the native-prevalence table, the S1 event
   curves, the within-patient sensitivity at one false alarm per hour, and
   the S1 calibration figures.

   The fix is the split the models were trained under: order each
   recording's windows in time, take the last thirty per cent, and score
   only those. This script rewrites the S1 scores accordingly, into a new
   directory, and reports the corrected figures beside the leaked ones so
   the size of the error is visible.

2. THE CROSS-PATIENT FOLDS WERE NEVER SCORED

   infer_local.py skipped all 100 S2 runs because it could not identify
   which subjects each fold held out. That assignment is recoverable:
   GroupKFold is deterministic given the subject array and the number of
   splits, so reconstructing it with the same subject ordering the sweep
   used reproduces the folds exactly. The script reconstructs them, scores
   them on continuous data, and checks the reconstruction by confirming
   that each fold's held-out subjects are disjoint and cover the cohort.

   Until this is done, the cross-patient figures in the paper come from the
   subsample while the cross-cohort figures come from continuous data, and
   the two are being compared as though they were measured the same way.

WHAT THIS DOES NOT FIX

   Nothing about the design. The comparison still changes the test set
   between settings, still aggregates differently in each, and still rests
   on one cohort pair. Those are addressed, if at all, by a different
   experiment and not by rescoring this one.

OUTPUT  D:\\refit\\scores\\  per-window scores, S1 corrected and S2 added
        D:\\refit\\refit.csv  the metrics, leaked and corrected side by side
=============================================================================
"""
from pathlib import Path
import sys, re, time, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd

SHARDS = Path(r"D:\xcohort_full")
WEIGHTS = Path(r"C:\Users\Anurag Tiwari\Downloads\results\weights")
OLD = Path(r"D:\native_inference\scores")
OUT = Path(r"D:\refit"); (OUT / "scores").mkdir(parents=True, exist_ok=True)

WIN_S, BATCH = 4.0, 1024
TRAIN_FRAC = 0.70          # the split the S1 models were trained under
N_FOLDS = 5                # GroupKFold splits used by the sweep

import torch, torch.nn as nn
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss
from sklearn.model_selection import GroupKFold
try:
    import braindecode.models as M
except ImportError:
    sys.exit("pip install braindecode")

DEV = "cuda" if torch.cuda.is_available() else "cpu"
def log(m): print(m, flush=True)


def shard_list():
    return {p.stem: p for p in SHARDS.glob("*.npz") if p.stem != "manifest"}


SH = shard_list()
if not SH:
    sys.exit("no shards in %s" % SHARDS)
CHB = sorted(s for s in SH if s.lower().startswith("chb"))
SIE = sorted(s for s in SH if s.upper().startswith("PN"))
log("%d shards (%d CHB-MIT, %d Siena) | device %s" % (len(SH), len(CHB), len(SIE), DEV))


def parse_run(rid):
    p = rid.split("_")
    si = next(i for i, x in enumerate(p) if x.startswith("s") and x[1:].isdigit())
    fold = "_".join(p[2:si])
    return p[0], p[1], fold, int(p[si][1:])


def build(name, n_ch=17, n_t=1024, sfreq=256.0):
    cls = getattr(M, name, None)
    if cls is None:
        return None
    for kw in (dict(n_chans=n_ch, n_outputs=2, n_times=n_t, sfreq=sfreq),
               dict(n_chans=n_ch, n_outputs=2, n_times=n_t),
               dict(n_chans=n_ch, n_outputs=2,
                    input_window_seconds=n_t / sfreq, sfreq=sfreq)):
        try:
            m = cls(**kw)
            with torch.no_grad():
                o = m(torch.zeros(2, n_ch, n_t))
            if o.ndim == 3:
                m = nn.Sequential(m, nn.AdaptiveAvgPool1d(1), nn.Flatten())
            return m
        except Exception:
            continue
    return None


def load_shard(name):
    z = np.load(SH[name], allow_pickle=True)
    if z["X"].size == 0:
        return None
    key = "rec" if "rec" in z.files else "file"
    return (z["X"], z["y"].astype(int), z[key].astype(str), z["order"].astype(int))


def test_mask_s1(y, rec, order):
    """The last 30 per cent of each recording, in time.

    The S1 models were trained on the first 70 per cent of each recording
    and this is the complement. Scoring the whole shard, as the earlier
    inference did, puts roughly seventy per cent of the training data into
    the test set."""
    keep = np.zeros(len(y), bool)
    for r in np.unique(rec):
        idx = np.where(rec == r)[0]
        idx = idx[np.argsort(order[idx])]
        cut = int(len(idx) * TRAIN_FRAC)
        keep[idx[cut:]] = True
    return keep


def score(model, X):
    out = []
    model.eval()
    with torch.no_grad():
        for i in range(0, len(X), BATCH):
            xb = torch.from_numpy(X[i:i + BATCH].astype(np.float32)).to(DEV)
            with torch.autocast(DEV, enabled=(DEV == "cuda")):
                o = model(xb)
            out.append(torch.softmax(o.float(), 1)[:, 1].cpu().numpy())
    return np.concatenate(out)


def s2_folds():
    """Reconstruct the cross-patient folds.

    GroupKFold is deterministic: given the same group labels in the same
    order and the same number of splits, it returns the same partition. The
    sweep grouped over CHB-MIT subjects in sorted order, which is what is
    rebuilt here. The reconstruction is checked below rather than assumed."""
    groups = np.array(CHB)
    gkf = GroupKFold(n_splits=N_FOLDS)
    folds = []
    for tr, te in gkf.split(np.zeros(len(groups)), np.zeros(len(groups)), groups):
        folds.append(sorted(groups[te]))
    seen = set()
    for f in folds:
        assert not (seen & set(f)), "folds overlap: the reconstruction is wrong"
        seen |= set(f)
    assert seen == set(CHB), "folds do not cover the cohort"
    log("\nreconstructed %d cross-patient folds, disjoint and covering:" % len(folds))
    for i, f in enumerate(folds):
        log("  fold %d (%d subjects): %s" % (i, len(f), " ".join(f)))
    return folds


def metrics(y, s):
    prev = float(y.mean()); ap = average_precision_score(y, s)
    return dict(n=int(len(y)), pos=int(y.sum()), prevalence=prev,
                auroc=float(roc_auc_score(y, s)), auprc=float(ap),
                lift=float(ap / prev), brier=float(brier_score_loss(y, s)),
                hours=float(len(y) * WIN_S / 3600))


def main():
    t0 = time.time()
    wts = sorted(WEIGHTS.glob("*.pt"))
    if not wts:
        sys.exit("no weights in %s" % WEIGHTS)
    log("%d weight files" % len(wts))
    folds = s2_folds()
    rows = []

    for k, w in enumerate(wts, 1):
        rid = w.stem
        try:
            name, setting, fold, seed = parse_run(rid)
        except Exception:
            continue
        if setting == "S1":
            if fold not in SH:
                continue
            subs = [fold]
        elif setting == "S2":
            m = re.search(r"fold(\d+)", fold)
            if not m or int(m.group(1)) >= len(folds):
                continue
            subs = folds[int(m.group(1))]
        else:
            continue                      # S3 was scored correctly already

        out = OUT / "scores" / (rid + ".npz")
        if out.exists():
            continue
        ck = torch.load(w, map_location="cpu", weights_only=False)
        sd = ck.get("state_dict", ck)
        model = build(name, ck.get("n_chans", 17), ck.get("n_times", 1024))
        if model is None:
            continue
        try:
            model.load_state_dict(sd)
        except Exception:
            continue
        model = model.to(DEV)

        S, Y, R_, O_ = [], [], [], []
        for sname in subs:
            d = load_shard(sname)
            if d is None:
                continue
            X, y, rec, order = d
            if setting == "S1":
                keep = test_mask_s1(y, rec, order)
                X, y, rec, order = X[keep], y[keep], rec[keep], order[keep]
            if len(y) == 0:
                continue
            S.append(score(model, X)); Y.append(y); R_.append(rec); O_.append(order)
        del model
        if DEV == "cuda":
            torch.cuda.empty_cache()
        if not S or len(np.unique(np.concatenate(Y))) < 2:
            continue
        s = np.concatenate(S); y = np.concatenate(Y)
        rec = np.concatenate(R_); order = np.concatenate(O_)
        np.savez_compressed(out, score=s.astype(np.float32),
                            label=y.astype(np.int8), rec=rec,
                            order=order.astype(np.int32))
        r = metrics(y, s)
        r.update(run_id=rid, model=name, setting=setting, fold=fold, seed=seed)

        if setting == "S1":
            o = OLD / (rid + ".npz")
            if o.exists():
                z = np.load(o, allow_pickle=True)
                yo, so = z["label"].astype(int), z["score"].astype(float)
                if len(np.unique(yo)) > 1:
                    r["auroc_leaked"] = float(roc_auc_score(yo, so))
                    r["n_leaked"] = int(len(yo))
        rows.append(r)
        pd.DataFrame([r]).to_csv(OUT / "refit.csv", mode="a",
            header=not (OUT / "refit.csv").exists(), index=False)
        if k % 10 == 0 or setting == "S2":
            log("[%3d/%d] %-42s %s AUROC %.3f%s | %.1f min"
                % (k, len(wts), rid, setting, r["auroc"],
                   ("  leaked %.3f" % r["auroc_leaked"]) if "auroc_leaked" in r else "",
                   (time.time() - t0) / 60))

    d = pd.DataFrame(rows)
    if d.empty:
        log("nothing scored"); return
    log("\n" + "#" * 70)
    log("CORRECTED FIGURES")
    log("#" * 70)
    for st in sorted(d.setting.unique()):
        g = d[d.setting == st]
        log("\n%s  (%d runs, %.0f h per run)" % (st, len(g), g.hours.mean()))
        log(g.groupby("model")[["auroc", "auprc", "lift"]].mean().round(4).to_string())
        log("  pooled AUROC %.4f  AUPRC %.4f  lift %.1fx  prevalence %.5f"
            % (g.auroc.mean(), g.auprc.mean(), g.lift.mean(), g.prevalence.mean()))
    if "auroc_leaked" in d.columns:
        s1 = d[(d.setting == "S1") & d.auroc_leaked.notna()]
        if not s1.empty:
            log("\nwithin-patient, the size of the leak:")
            log("  scored on the whole shard  %.4f" % s1.auroc_leaked.mean())
            log("  scored on the held-out 30%% %.4f" % s1.auroc.mean())
            log("  difference                 %.4f" % (s1.auroc_leaked.mean() - s1.auroc.mean()))
            log("  windows: %d against %d" % (s1.n_leaked.mean(), s1.n.mean()))
    log("\nwritten to %s" % OUT)
    log("%.1f min" % ((time.time() - t0) / 60))


if __name__ == "__main__":
    main()
