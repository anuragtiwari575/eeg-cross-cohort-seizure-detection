"""
=============================================================================
THREE SENSITIVITY CHECKS
=============================================================================
    python -u sensitivity.py

CPU only, roughly two to three hours. Closes three caveats currently carried
in the manuscript. Nothing existing is overwritten; output goes to
D:\\sensitivity.

WHAT IT CHECKS AND WHY

1. SUBJECT-GROUPED FEATURE PROBES

   The paper reports that cohort identity, subject identity and the seizure
   label are recoverable from the features at 0.92, 0.95 and 0.81. Those
   figures came from window-stratified folds, so windows from one subject
   could fall on both sides of a split. For the subject probe that is
   unavoidable, since subject identity is the target. For the cohort and
   seizure probes it is not, and it makes both an upper bound rather than an
   estimate of what transfers.

   Here the cohort and seizure probes are rerun with folds grouped by
   subject. If the figures hold, the caveat can be dropped; if they fall,
   the honest numbers are the grouped ones and the mechanism argument has to
   be restated around them.

2. PREVALENCE SWEEP ON THE FEATURE SET ACTUALLY USED

   The sweep in the paper was computed on the spectral-only arm, which the
   feature ablation superseded. The qualitative claim does not depend on the
   arm, but the absolute values quoted alongside it do, and at present the
   text has to carry a sentence saying so. Rerunning on A+B+C removes the
   need for that sentence.

3. CAUSAL NORMALISATION

   Each channel is currently z-scored using statistics from the whole
   recording, computed before windowing. That is transductive: in the
   within-patient setting the statistics include the held-out portion. No
   labels leak and every method receives the same treatment, so the
   comparison between methods is unaffected, but the absolute figures
   describe an offline analysis rather than a prospective one.

   This recomputes the features that can be recomputed cheaply --- relative
   band power and the temporal family, 136 of the 170 features in the arm
   used --- under two causal alternatives: statistics from the first two
   minutes of each recording, and statistics from a 30 s window preceding
   each analysis window. The aperiodic family is not recomputed, since
   spectral parameterisation over a million windows is a three-hour job on
   its own; the comparison is therefore between like sets, A+C under each
   normalisation, rather than the full arm.

   If the three normalisations agree, the transductive choice is not doing
   any work and the caveat becomes a sensitivity result. If they disagree,
   that is worth knowing before submission rather than after.

OUTPUT  D:\\sensitivity\\
    probes_grouped.csv, prevalence_abc.csv, normalisation.csv
    and a summary printed at the end
=============================================================================
"""
from pathlib import Path
import sys, time, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd

CACHE  = Path(r"D:\ablation\cache")        # 272-feature matrices per subject
SHARDS = Path(r"D:\xcohort_full")          # raw windows
OUT    = Path(r"D:\sensitivity"); OUT.mkdir(parents=True, exist_ok=True)

FS, WIN_S = 256.0, 4.0
NB, N_FEAT = 85, 272
SEED = 1234
MAX_TRAIN = 150_000
PREVS = [0.50, 0.25, 0.10, 0.0736, 0.05, 0.01, None]
LEAD_S = 120.0      # causal option A: first two minutes of the recording
PRE_S  = 30.0       # causal option B: 30 s before each window

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.model_selection import GroupKFold, StratifiedKFold, cross_val_score

def log(m): print(m, flush=True)


# ----------------------------------------------------------------- load
def load_cached():
    fs = sorted(CACHE.glob("*.npz"))
    if not fs:
        sys.exit("no cache in %s -- run ablation.py first" % CACHE)
    X, y, sub, coh = [], [], [], []
    for f in fs:
        d = np.load(f, allow_pickle=True)
        if d["X"].size == 0:
            continue
        X.append(d["X"]); y.append(d["y"])
        sub.append(np.full(len(d["y"]), f.stem))
        coh.append(np.full(len(d["y"]),
                           "chb" if f.stem.lower().startswith("chb") else "siena"))
    X = np.vstack(X); y = np.concatenate(y)
    sub = np.concatenate(sub); coh = np.concatenate(coh)
    ok = np.isfinite(X).all(1)
    return X[ok], y[ok], sub[ok], coh[ok]


log("loading cached features")
X, y, sub, coh = load_cached()
log("%d windows, %d features, %d positive (%.3f%%), %d subjects"
    % (X.shape[0], X.shape[1], y.sum(), 100 * y.mean(), len(np.unique(sub))))

BLOCKS, off = {}, 0
for fam, w in (("bandpower", NB), ("aperiodic", 119 - NB),
               ("ll", 17), ("tkeo", 34), ("wave", 102)):
    BLOCKS[fam] = np.arange(off, off + w); off += w
ABC = np.concatenate([BLOCKS[k] for k in ("bandpower", "aperiodic", "ll", "tkeo")])
AC  = np.concatenate([BLOCKS[k] for k in ("bandpower", "ll", "tkeo")])


def lr():
    return make_pipeline(StandardScaler(),
                         LogisticRegression(max_iter=1000,
                                            class_weight="balanced"))


def fit_predict(cols, tr, te, seed=SEED):
    Xtr, ytr = X[np.ix_(tr, cols)], y[tr]
    if len(ytr) > MAX_TRAIN:
        r = np.random.default_rng(seed)
        pos = np.where(ytr == 1)[0]; neg = np.where(ytr == 0)[0]
        neg = r.choice(neg, max(1, min(len(neg), MAX_TRAIN - len(pos))),
                       replace=False)
        k = np.concatenate([pos, neg]); Xtr, ytr = Xtr[k], ytr[k]
    m = lr(); m.fit(Xtr, ytr)
    return m.predict_proba(X[np.ix_(te, cols)])[:, 1]


# ================================================================= 1
def probes():
    log("\n" + "=" * 72)
    log("1. FEATURE PROBES WITH SUBJECT-GROUPED FOLDS")
    log("=" * 72)
    log("Cohort and seizure probes rerun with folds grouped by subject, so")
    log("no subject appears on both sides of a split. The subject probe is")
    log("left ungrouped, since grouping on the target is incoherent.\n")
    rng = np.random.default_rng(SEED)
    idx = []
    for s in np.unique(sub):
        m = np.where(sub == s)[0]
        idx.append(rng.choice(m, min(400, len(m)), replace=False))
    idx = np.concatenate(idx)
    pos = np.where(y == 1)[0]
    idx = np.unique(np.concatenate([idx, rng.choice(pos, min(2000, len(pos)),
                                                    replace=False)]))
    Xs, ys, ss, cs = X[idx][:, ABC], y[idx], sub[idx], coh[idx]
    rows = []

    gkf = GroupKFold(n_splits=5)
    skf = StratifiedKFold(5, shuffle=True, random_state=SEED)

    ci = pd.factorize(cs)[0]
    a_g = cross_val_score(lr(), Xs, ci, cv=gkf.split(Xs, ci, ss),
                          scoring="roc_auc").mean()
    a_u = cross_val_score(lr(), Xs, ci, cv=skf, scoring="roc_auc").mean()
    rows.append(dict(target="cohort", grouped=a_g, ungrouped=a_u))
    log("  cohort identity   grouped %.3f   ungrouped %.3f" % (a_g, a_u))

    if len(np.unique(ys)) > 1:
        y_g = cross_val_score(lr(), Xs, ys, cv=gkf.split(Xs, ys, ss),
                              scoring="roc_auc").mean()
        y_u = cross_val_score(lr(), Xs, ys, cv=skf, scoring="roc_auc").mean()
        rows.append(dict(target="seizure", grouped=y_g, ungrouped=y_u))
        log("  seizure label     grouped %.3f   ungrouped %.3f" % (y_g, y_u))

    aucs = []
    for s in np.unique(ss):
        lab = (ss == s).astype(int)
        if lab.sum() < 50:
            continue
        try:
            aucs.append(cross_val_score(lr(), Xs, lab, cv=skf,
                                        scoring="roc_auc").mean())
        except Exception:
            pass
    if aucs:
        rows.append(dict(target="subject", grouped=np.nan,
                         ungrouped=float(np.mean(aucs))))
        log("  subject identity  ungrouped %.3f  (grouping is incoherent here)"
            % np.mean(aucs))
    pd.DataFrame(rows).to_csv(OUT / "probes_grouped.csv", index=False)


# ================================================================= 2
def prevalence():
    log("\n" + "=" * 72)
    log("2. PREVALENCE SWEEP ON A+B+C")
    log("=" * 72)
    CHB = np.where(coh == "chb")[0]; SIE = np.where(coh == "siena")[0]
    rng = np.random.default_rng(SEED)
    rows = []
    for setting, tr, te in (("S3-fwd", CHB, SIE), ("S3-rev", SIE, CHB)):
        s = fit_predict(ABC, tr, te)
        yy = y[te]
        p_i = np.where(yy == 1)[0]; n_i = np.where(yy == 0)[0]
        for p in PREVS:
            if p is None:
                sel = np.arange(len(yy))
            else:
                nn = int(round(len(p_i) * (1 - p) / p))
                if nn > len(n_i):
                    continue
                sel = np.concatenate([p_i, rng.choice(n_i, nn, replace=False)])
            prev = float(yy[sel].mean())
            ap = average_precision_score(yy[sel], s[sel])
            rows.append(dict(setting=setting, target_prev=p or prev,
                             prevalence=prev, n=len(sel),
                             auroc=roc_auc_score(yy[sel], s[sel]),
                             auprc=ap, lift=ap / prev))
    d = pd.DataFrame(rows)
    d.to_csv(OUT / "prevalence_abc.csv", index=False)
    g = d.groupby("target_prev")[["auroc", "auprc", "lift"]].mean()
    log(g.round(4).to_string())
    log("\n  AUROC range %.3f | AUPRC ratio %.0fx"
        % (g.auroc.max() - g.auroc.min(), g.auprc.max() / g.auprc.min()))


# ================================================================= 3
BATCH = 4096       # the largest recording set holds 140k windows; one FFT
                   # over all of them needs 18 GB, so they go in batches


def bandpower_from_raw(W):
    """Relative band power per channel, in batches.

    float32 throughout: the default complex128 output of rfft is what made
    the whole-array version exceed memory."""
    n, c, t = W.shape
    f = np.fft.rfftfreq(t, 1 / FS).astype(np.float32)
    bands = [(f >= lo) & (f < hi)
             for lo, hi in ((1, 4), (4, 8), (8, 13), (13, 30), (30, 40))]
    inband = (f >= 1) & (f <= 40)
    out = np.empty((n, c * 5), np.float32)
    for i in range(0, n, BATCH):
        w = W[i:i + BATCH].astype(np.float32)
        P = (np.abs(np.fft.rfft(w, axis=2)) ** 2).astype(np.float32)
        tot = P[:, :, inband].sum(2) + 1e-12
        out[i:i + BATCH] = np.concatenate(
            [P[:, :, b].sum(2) / tot for b in bands], 1)
        del P, w
    return out


def temporal_from_raw(W):
    n, c, t = W.shape
    out = np.empty((n, c * 3), np.float32)
    for i in range(0, n, BATCH):
        w = W[i:i + BATCH].astype(np.float32)
        ll = np.abs(np.diff(w, axis=2)).sum(2)
        p = w[:, :, 1:-1] ** 2 - w[:, :, :-2] * w[:, :, 2:]
        out[i:i + BATCH] = np.concatenate([ll, p.mean(2), p.std(2)], 1)
        del w, p
    return out


def normalisation():
    log("\n" + "=" * 72)
    log("3. CAUSAL NORMALISATION")
    log("=" * 72)
    log("Band power and the temporal family recomputed from the raw windows")
    log("under three normalisation rules. The aperiodic family is left out:")
    log("respectral parameterisation of a million windows is a job of its own,")
    log("so the comparison is between like sets (A+C) rather than the full arm.\n")

    fs = sorted(SHARDS.glob("*.npz"))
    fs = [f for f in fs if f.stem != "manifest"]
    store = {k: [] for k in ("whole", "lead", "pre")}
    ys, ss, cs = [], [], []
    lead_n = int(LEAD_S / WIN_S)
    pre_n = int(PRE_S / WIN_S)
    t0 = time.time()

    for i, f in enumerate(fs, 1):
        z = np.load(f, allow_pickle=True)
        if z["X"].size == 0:
            continue
        W = z["X"].astype(np.float32)          # already whole-recording z-scored
        yy = z["y"].astype(int)
        key = "rec" if "rec" in z.files else "file"
        rec = z[key].astype(str); od = z["order"].astype(int)

        # the shards hold whole-recording normalised data. Undoing that
        # exactly is not possible, so the causal variants are applied on top:
        # each rescales by statistics drawn only from earlier windows, which
        # is the property under test.
        for mode in ("whole", "lead", "pre"):
            Wm = W
            if mode != "whole":
                Wm = np.empty_like(W)
                for r in np.unique(rec):
                    m = np.where(rec == r)[0]
                    m = m[np.argsort(od[m])]
                    blk = W[m]
                    if mode == "lead":
                        ref = blk[:min(lead_n, len(blk))]
                        mu = ref.mean((0, 2), keepdims=True)
                        sd = ref.std((0, 2), keepdims=True) + 1e-6
                        Wm[m] = (blk - mu) / sd
                    else:
                        out = np.empty_like(blk)
                        for j in range(len(blk)):
                            a = max(0, j - pre_n)
                            ref = blk[a:j] if j > a else blk[:1]
                            mu = ref.mean((0, 2), keepdims=True)[0]
                            sd = ref.std((0, 2), keepdims=True)[0] + 1e-6
                            out[j] = (blk[j] - mu) / sd
                        Wm[m] = out
            store[mode].append(np.concatenate(
                [bandpower_from_raw(Wm), temporal_from_raw(Wm)], 1))
            if Wm is not W:
                del Wm
        ys.append(yy); ss.append(np.full(len(yy), f.stem))
        cs.append(np.full(len(yy), "chb" if f.stem.lower().startswith("chb")
                          else "siena"))
        log("  [%2d/%d] %-7s (%.1f min)" % (i, len(fs), f.stem, (time.time()-t0)/60))

    yy = np.concatenate(ys); s2 = np.concatenate(ss); c2 = np.concatenate(cs)
    rows = []
    for mode in ("whole", "lead", "pre"):
        F = np.vstack(store[mode])
        ok = np.isfinite(F).all(1)
        CHB = np.where((c2 == "chb") & ok)[0]; SIE = np.where((c2 == "siena") & ok)[0]
        for setting, tr, te in (("S3-fwd", CHB, SIE), ("S3-rev", SIE, CHB)):
            Xtr, ytr = F[tr], yy[tr]
            if len(ytr) > MAX_TRAIN:
                r = np.random.default_rng(SEED)
                p = np.where(ytr == 1)[0]; n = np.where(ytr == 0)[0]
                n = r.choice(n, max(1, min(len(n), MAX_TRAIN - len(p))), replace=False)
                k = np.concatenate([p, n]); Xtr, ytr = Xtr[k], ytr[k]
            m = lr(); m.fit(Xtr, ytr)
            sc = m.predict_proba(F[te])[:, 1]
            prev = float(yy[te].mean()); ap = average_precision_score(yy[te], sc)
            rows.append(dict(normalisation=mode, setting=setting,
                             auroc=roc_auc_score(yy[te], sc), auprc=ap,
                             lift=ap / prev))
            log("  %-6s %-7s AUROC %.3f  lift %.1fx"
                % (mode, setting, rows[-1]["auroc"], rows[-1]["lift"]))
    d = pd.DataFrame(rows)
    d.to_csv(OUT / "normalisation.csv", index=False)
    log("\n" + d.pivot_table(index="normalisation", columns="setting",
                             values="auroc").round(3).to_string())
    w = d[d.normalisation == "whole"].auroc.mean()
    for mode in ("lead", "pre"):
        v = d[d.normalisation == mode].auroc.mean()
        log("  %-6s differs from whole-recording by %+.3f" % (mode, v - w))
    log("\nIf these agree, the transductive choice is not doing any work and")
    log("the caveat becomes a sensitivity result rather than a limitation.")


if __name__ == "__main__":
    t0 = time.time()
    todo = sys.argv[1:] or ["probes", "prevalence", "normalisation"]
    for fn in [f for f in (probes, prevalence, normalisation)
               if f.__name__ in todo]:
        try:
            fn()
        except Exception as e:
            log("FAILED %s: %s: %s" % (fn.__name__, type(e).__name__, e))
            import traceback; traceback.print_exc()
    log("\nwall time %.1f min | results in %s" % ((time.time() - t0) / 60, OUT))
