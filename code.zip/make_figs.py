"""
=============================================================================
THE THREE FIGURES THIS PAPER STILL NEEDS
=============================================================================
    python -u make_figs.py

Writes F16, F17 and F18 to D:\\figures as PDF and PNG.

WHY THESE THREE

F16  THE BOUNDARY REVERSAL

     The paper's central result is that the same models, the same weights
     and the same boundaries give opposite answers depending on which data
     each setting is scored on, and again depending on which arm measures
     it. That currently has to be assembled by the reader from two tables.
     One figure shows it.

F17  ARCHITECTURE AGAINST ITS NULL

     The permutation test is reported as three p values. Plotted against
     the null distribution it shows at a glance that the within-patient
     range clears the null and the two transfer ranges do not, which is
     the claim the paper makes about architecture.

F18  EVENT LEVEL ON CONTINUOUS RECORDING

     The clinical result, that between five and eighteen per cent of
     seizures are detected at one false alarm per hour, is the strongest
     thing in the paper for a clinical reader and has no figure at all.
     Both directions are drawn because they differ by threefold at that
     operating point.

All numbers are the final ones, taken from the corrected-label run. They
are written literally here rather than read from disk so that the figure
cannot drift from the manuscript: if a number changes, it changes in one
place and the figure fails to match the paper visibly rather than silently.
=============================================================================
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = Path(r"D:\figures"); OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.titlesize": 8.5, "axes.labelsize": 8,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
    "legend.frameon": False, "legend.fontsize": 7,
    "figure.dpi": 150, "savefig.bbox": "tight",
})
C = dict(blue="#2E5E8E", orange="#C1622C", green="#3E7A55", red="#A33A3A",
         purple="#6B4C86", grey="#8A8A8A", light="#D8D8D8")


def save(fig, name):
    fig.savefig(OUT / (name + ".pdf"))
    fig.savefig(OUT / (name + ".png"), dpi=200)
    plt.close(fig)
    print("  wrote %s" % name)


# ------------------------------------------------------------------ F16
def f16():
    """The same boundaries, measured two ways, twice."""
    print("F16 boundary reversal")
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.9))

    # (a) the scoring-data reversal, learned arm
    x = [0, 1, 2]
    sub = [0.942, 0.870, 0.847]          # S1, S2 on the subsample; S3 continuous
    con = [0.958, 0.949, 0.856]          # all three on continuous recording
    ax[0].plot(x, sub, "o--", color=C["grey"], ms=5, lw=1.3,
               label="S1, S2 on the subsample")
    ax[0].plot(x, con, "o-", color=C["blue"], ms=5, lw=1.8,
               label="all three on continuous data")
    for xi, a, b in zip(x, sub, con):
        ax[0].plot([xi, xi], [a, b], color=C["light"], lw=0.8, zorder=0)
    ax[0].annotate("", xy=(1, 0.870), xytext=(0, 0.942),
                   arrowprops=dict(arrowstyle="-", color=C["grey"], lw=0))
    ax[0].text(0.5, 0.900, "0.072", ha="center", fontsize=7, color=C["grey"])
    ax[0].text(1.5, 0.862, "0.024", ha="center", fontsize=7, color=C["grey"])
    ax[0].text(0.5, 0.958, "0.008", ha="center", fontsize=7, color=C["blue"])
    ax[0].text(1.5, 0.912, "0.093", ha="center", fontsize=7, color=C["blue"])
    ax[0].set_xticks(x)
    ax[0].set_xticklabels(["within\npatient", "cross\npatient", "cross\ncohort"])
    ax[0].set_ylabel("AUROC"); ax[0].set_ylim(0.80, 0.99)
    ax[0].legend(loc="lower left")
    ax[0].set_title("(a) which data each setting is scored on", loc="left")

    # (b) the two arms on identical windows
    arms = ["learned", "handcrafted"]
    s2 = [0.949, 0.801]; s3 = [0.856, 0.794]
    xp = np.arange(2); w = 0.32
    ax[1].bar(xp - w/2, s2, w, color=C["blue"], label="cross-patient")
    ax[1].bar(xp + w/2, s3, w, color=C["orange"], label="cross-cohort")
    for i in range(2):
        d = s2[i] - s3[i]
        top = max(s2[i], s3[i]) + 0.016
        ax[1].plot([xp[i]-w/2, xp[i]+w/2], [top, top], color="#444", lw=0.8)
        ax[1].text(xp[i], top + 0.006, "drop %.3f" % d, ha="center", fontsize=7)
        ax[1].text(xp[i]-w/2, s2[i]-0.035, "%.3f" % s2[i], ha="center",
                   fontsize=6.5, color="white")
        ax[1].text(xp[i]+w/2, s3[i]-0.035, "%.3f" % s3[i], ha="center",
                   fontsize=6.5, color="white")
    ax[1].set_xticks(xp); ax[1].set_xticklabels(arms)
    ax[1].set_ylim(0.70, 1.06); ax[1].set_ylabel("AUROC")
    ax[1].legend(loc="upper right", ncol=2, columnspacing=1.0,
                 handlelength=1.2, bbox_to_anchor=(1.02, 1.02))
    ax[1].set_title("(b) which arm measures it", loc="left")
    ax[1].text(0.5, -0.20, "identical windows, identical splits",
               ha="center", fontsize=7, color="#666",
               transform=ax[1].transAxes)
    fig.tight_layout(); save(fig, "F16_reversal")


# ------------------------------------------------------------------ F17
def f17():
    """Observed architecture spread against the permutation threshold.

    Only measured quantities are drawn: the observed range of architecture
    means, and the 95th percentile of the blocked-permutation null. The
    5000 permutation draws themselves were not saved, so no histogram is
    shown; drawing a synthetic distribution that looked like the real one
    would be worse than drawing none."""
    print("F17 architecture against its null")
    rows = [("S1\nwithin-patient", 0.0714, 0.0368, "$p<0.001$"),
            ("S2\ncross-patient",  0.0116, 0.0212, "$p=0.51$"),
            ("S3\ncross-cohort",   0.0207, 0.0230, "$p=0.11$")]
    fig, ax = plt.subplots(figsize=(4.6, 2.9))
    y = np.arange(len(rows))[::-1]
    for yi, (lab, obs, p95, p) in zip(y, rows):
        sig = obs > p95
        ax.plot([0, p95], [yi, yi], color=C["light"], lw=7, solid_capstyle="butt")
        ax.plot([p95, p95], [yi - .22, yi + .22], color=C["grey"], lw=1.4)
        ax.plot(obs, yi, "o", ms=8,
                color=C["red"] if sig else C["blue"], zorder=3)
        ax.text(obs, yi + .30, "%.3f" % obs, ha="center", fontsize=7,
                color=C["red"] if sig else C["blue"])
        ax.text(0.078, yi, p, fontsize=7.5, va="center")
    ax.text(0.0368, len(rows) - 0.55, "null 95th percentile", fontsize=6.8,
            color=C["grey"], ha="center")
    ax.set_yticks(y); ax.set_yticklabels([r[0] for r in rows])
    ax.set_xlim(0, 0.098); ax.set_ylim(-0.6, len(rows) - 0.35)
    ax.set_xlabel("range of architecture means (AUROC)")
    ax.set_title("Architecture spread against a blocked-permutation null",
                 loc="left")
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)
    fig.tight_layout(); save(fig, "F17_architecture_null")


# ------------------------------------------------------------------ F18
def f18():
    """Event-level sensitivity against false alarms per hour, both directions."""
    print("F18 event level")
    fa = [0.10, 0.25, 0.50, 1.00, 2.00, 5.00]
    fwd = [0.000, 0.026, 0.053, 0.053, 0.158, 0.579]
    rev = [0.076, 0.092, 0.108, 0.178, 0.259, 0.432]
    fig, ax = plt.subplots(figsize=(4.4, 3.1))
    ax.plot(fa, fwd, "o-", color=C["orange"], ms=4.5, lw=1.6,
            label="CHB-MIT $\\rightarrow$ Siena (38 events, 141 h)")
    ax.plot(fa, rev, "s-", color=C["green"], ms=4.5, lw=1.6,
            label="Siena $\\rightarrow$ CHB-MIT (185 events, 970 h)")
    ax.axvline(1.0, color=C["grey"], ls="--", lw=0.9)
    ax.text(1.05, 0.60, "one false alarm\nper hour", fontsize=6.8, color="#666")
    ax.annotate("", xy=(1.0, 0.053), xytext=(1.0, 0.178),
                arrowprops=dict(arrowstyle="<->", color="#444", lw=0.9))
    ax.text(0.62, 0.112, "5% to 18%", fontsize=7, color="#333", ha="right")
    ax.set_xscale("log")
    ax.set_xticks(fa); ax.set_xticklabels([str(v) for v in fa])
    ax.set_xlabel("false alarms per hour")
    ax.set_ylabel("seizures detected")
    ax.set_ylim(0, 0.72)
    ax.legend(loc="upper left")
    ax.set_title("Handcrafted A+B+C on continuous recording", loc="left")
    fig.tight_layout(); save(fig, "F18_event_level")



# ------------------------------------------------------------------ F5
def f5():
    """Negative controls, on the arm the paper uses.

    The published panel plots the spectral-only arm and a recording-context
    control run on features that are invariant to per-channel scaling and
    therefore could not have detected an amplitude signature. Both are
    redrawn here on A+B+C after the annotation correction."""
    print("F5 negative controls")
    bars = [("actual labels\n(A+B+C, cross-cohort)", 0.794, C["blue"]),
            ("labels permuted\nwithin subject",      0.495, C["grey"]),
            ("recording context\n(A+B+C)",           0.506, C["grey"]),
            ("recording context\n(A+B, spectral)",   0.529, C["light"])]
    err = [0.013, 0.021, 0.009, 0.011]
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    x = np.arange(len(bars))
    ax.bar(x, [b[1] for b in bars], 0.6, yerr=err, capsize=3,
           color=[b[2] for b in bars], error_kw=dict(lw=0.9, ecolor="#555"))
    ax.axhline(0.5, color=C["red"], ls="--", lw=1)
    ax.text(3.45, 0.508, "chance", fontsize=6.8, color=C["red"], ha="right")
    for xi, b in zip(x, bars):
        ax.text(xi, b[1] + err[x.tolist().index(xi)] + 0.012, "%.3f" % b[1],
                ha="center", fontsize=7)
    ax.set_xticks(x)
    ax.set_xticklabels([b[0] for b in bars], fontsize=6.6)
    ax.set_ylim(0.40, 0.88); ax.set_ylabel("AUROC")
    ax.set_title("Negative controls", loc="left")
    fig.tight_layout(); save(fig, "F5_controls")


# ------------------------------------------------------------------ F3
def f3():
    """The prevalence sweep, on the arm the paper uses.

    The model is held fixed and only the class balance of the evaluation set
    is varied. Both arms are drawn because the contrast between them is the
    point: the weaker detector's sweep looks more dramatic."""
    print("F3 prevalence sweep")
    prev = np.array([0.00323, 0.00463, 0.01, 0.05, 0.0736, 0.10, 0.25, 0.50])
    abc_auroc = np.array([0.7869, 0.7890, 0.7885, 0.7888, 0.7875, 0.7881, 0.7903, 0.7963])
    abc_auprc = np.array([0.0430, 0.0503, 0.0977, 0.2871, 0.3637, 0.4244, 0.6463, 0.8224])
    ab_auroc  = np.array([0.6796, 0.6912, 0.6880, 0.6875, 0.6868, 0.6871, 0.6890, 0.6955])
    ab_auprc  = np.array([0.0100, 0.0118, 0.0243, 0.1102, 0.1686, 0.2115, 0.4180, 0.6680])

    fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.9))
    for a in ax:
        a.set_xscale("log"); a.set_xlabel("evaluation prevalence")
        a.axvspan(0.20, 0.60, color="#F2F2F2", zorder=0)
        a.axvline(0.0035, color="#666", ls="--", lw=0.9)
    ax[0].plot(prev, abc_auroc, "o-", color=C["blue"], ms=4, label="A+B+C")
    ax[0].plot(prev, ab_auroc, "s--", color=C["grey"], ms=4, label="A+B")
    ax[0].axhline(0.5, color=C["light"], ls=":", lw=1)
    ax[0].set_ylabel("AUROC"); ax[0].set_ylim(0.45, 0.88)
    ax[0].text(0.0038, 0.855, "native", fontsize=6.5, color="#666")
    ax[0].text(0.34, 0.855, "balanced", fontsize=6.5, color="#666", ha="center")
    ax[0].annotate("range 0.009", xy=(0.02, 0.80), fontsize=7, color=C["blue"])
    ax[0].annotate("range 0.012", xy=(0.02, 0.665), fontsize=7, color=C["grey"])
    ax[0].legend(loc="lower left")
    ax[0].set_title("(a) AUROC is prevalence-invariant", loc="left")

    ax[1].plot(prev, abc_auprc, "o-", color=C["blue"], ms=4, label="A+B+C")
    ax[1].plot(prev, ab_auprc, "s--", color=C["grey"], ms=4, label="A+B")
    ax[1].plot(prev, prev, ":", color=C["red"], lw=1.2, label="chance = prevalence")
    ax[1].set_yscale("log"); ax[1].set_ylabel("AUPRC")
    ax[1].text(0.011, 0.055, "$\\times$19", fontsize=7.5, color=C["blue"])
    ax[1].text(0.011, 0.011, "$\\times$67", fontsize=7.5, color=C["grey"])
    ax[1].legend(loc="upper left")
    ax[1].set_title("(b) AUPRC is not", loc="left")
    fig.tight_layout(); save(fig, "F3_prevalence")



# ------------------------------------------------------------------ F1
def f1():
    """The study design.

    The published version of this diagram carried several statements that
    the manuscript no longer makes: a window count from before the
    annotation correction, 23 subjects where the unit is 24 recording sets,
    a cross-patient split described as grouped over subjects rather than
    over patients, and the two transfer directions shown as one symmetric
    arrow when only one of them nests inside the other two settings."""
    print("F1 study design")
    from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")

    def box(x, y, w, h, title, lines, fc="#FFFFFF", ec="#555", ts=8, ls=6.8):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08",
                                    fc=fc, ec=ec, lw=1.0))
        ax.text(x + w/2, y + h - 0.26, title, ha="center", va="top",
                fontsize=ts, fontweight="bold")
        for i, l in enumerate(lines):
            ax.text(x + w/2, y + h - 0.62 - i*0.30, l, ha="center", va="top",
                    fontsize=ls, color="#333")

    def arrow(x1, y1, x2, y2, lab=None, style="-|>"):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style,
                                     mutation_scale=11, color="#666", lw=1.0,
                                     shrinkA=1, shrinkB=1))
        if lab:
            ax.text((x1+x2)/2 + 0.12, (y1+y2)/2, lab, fontsize=6.2,
                    color="#666", va="center")

    # cohorts
    box(0.2, 7.9, 4.5, 1.9, "CHB-MIT",
        ["24 recording sets, 23 patients", "paediatric, 256 Hz, bipolar",
         "60 Hz notch already applied"], fc="#EAF0F6")
    box(5.3, 7.9, 4.5, 1.9, "Siena",
        ["14 adult subjects", "512 Hz, referential",
         "50 Hz line noise, un-notched"], fc="#F6EEE8")

    # preprocessing
    box(1.5, 5.7, 7.0, 1.8, "Preprocessing, identical for both",
        ["17 bipolar derivations  |  1–40 Hz zero-phase  |  256 Hz",
         "each channel z-scored over the complete recording",
         "4 s windows, no overlap; $\\geq$50% inside a seizure is positive,",
         "partial overlap discarded"], fc="#F4F4F4")
    arrow(2.4, 7.9, 2.4, 7.5); arrow(7.6, 7.9, 7.6, 7.5)

    # the corpus
    box(2.4, 4.5, 5.2, 0.95, "1\u2009000\u2009277 windows over 1111 hours",
        ["3546 positive (0.35%)  |  Siena 728 of 126\u2009849"], fc="#FFFFFF")
    arrow(5.0, 5.7, 5.0, 5.45)

    # settings
    box(0.2, 2.0, 3.0, 2.1, "S1  within-patient",
        ["first 70% of each", "recording for training,", "last 30% for testing",
         "", "CHB-MIT only"], fc="#EAF0F6")
    box(3.5, 2.0, 3.0, 2.1, "S2  cross-patient",
        ["grouped five-fold over", "CHB-MIT patients", "chb01 and chb21 together",
         "", "CHB-MIT only"], fc="#EAF0F6")
    box(6.8, 2.0, 3.0, 2.1, "S3  cross-cohort",
        ["CHB-MIT $\\rightarrow$ Siena", "(nested in S1 and S2)",
         "Siena $\\rightarrow$ CHB-MIT", "(reverse direction)", ""], fc="#F6EEE8")
    for x in (1.7, 5.0, 8.3):
        arrow(5.0, 4.5, x, 4.15)

    # scoring
    box(1.5, 0.45, 7.0, 1.1, "Every setting scored on continuous recording",
        ["at the native prevalence of its own test set;",
         "no rebalancing at evaluation"], fc="#F4F4F4")
    for x in (1.7, 5.0, 8.3):
        arrow(x, 2.0, x, 1.6)

    fig.tight_layout(); save(fig, "F1_pipeline")


if __name__ == "__main__":
    f1(); f3(); f5(); f16(); f17(); f18()
    print("\nthree figures written to %s" % OUT)
    print("Every value drawn is a measured one. F17 shows the observed range")
    print("and the null 95th percentile rather than a histogram, because the")
    print("permutation draws were not saved and a synthetic distribution that")
    print("looked like the real one would mislead.")
