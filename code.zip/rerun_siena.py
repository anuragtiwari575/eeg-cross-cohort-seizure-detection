"""
=============================================================================
REBUILD SIENA FROM THE CORRECTED LABELS AND RERUN WHAT DEPENDS ON IT
=============================================================================
    python -u rerun_siena.py              everything, in order
    python -u rerun_siena.py shards       one stage only
    python -u rerun_siena.py --from feats  from that stage onward

Stages: labels, shards, feats, handcrafted, learned, causal, report.
The GPU stage is 'learned'; everything else is CPU. About six hours in
total, of which three are the GPU stage.

WHY ONE SCRIPT

Each stage consumes the one before it, and the failure that produced the
corrected labels in the first place was a stage being rerun while another
was not. Running them separately is how a feature file comes to disagree
with a window manifest. Each stage here writes a marker when it finishes, so
a rerun resumes rather than repeats, and the final stage refuses to report
if any marker is missing.

WHAT CHANGES AND WHAT DOES NOT

Only Siena labels changed. CHB-MIT is untouched, so:

    S1 within-patient        unaffected, not rerun
    S2 cross-patient         unaffected, not rerun
    S3 CHB-MIT -> Siena      test set changes; rerun
    S3 Siena -> CHB-MIT      training set changes; rerun

The within-patient and cross-patient figures in the manuscript therefore
stand as they are. Both cross-cohort directions are recomputed, and the
forward direction is the one the paper's principal comparison uses.

WHAT THE LABEL CORRECTION WAS

Three seizures were absent from the positive class: PN01's two, because its
annotation file writes "Start time" where every other file writes "Seizure
start time"; and PN00-3's, because its end time is an hour after the
recording ends and our parser discarded it. Three more of PN06's five were
attached to no recording because the file names are written PNO6 with a
letter O. All 47 are now recovered, 46 exactly as annotated and one with a
corrected end time.

OUTPUT  D:\\siena_v2\\
=============================================================================
"""
from pathlib import Path
import sys, time, json, shutil, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd

SIENA_DIR = Path(r"D:\CPU-Intel 7\C_Drive\archive\siena-scalp-eeg-database-1.0.0")
ANN       = Path(r"D:\siena_fixed\annotations.csv")
CHB_SHARD = Path(r"D:\xcohort_full")          # CHB-MIT shards, unchanged
CACHE_OLD = Path(r"D:\ablation\cache")        # CHB-MIT features, unchanged
WEIGHTS   = Path(r"C:\Users\Anurag Tiwari\Downloads\results\weights")
OUT       = Path(r"D:\siena_v2")
for d in ("shards", "cache", "scores", "marks"):
    (OUT / d).mkdir(parents=True, exist_ok=True)

FS, WIN_S, POS_OVERLAP = 256.0, 4.0, 0.5
SEED, MAX_TRAIN = 1234, 150_000
EPOCHS, BATCH, LR, VAL_FRAC = 14, 128, 1e-3, 0.10
SUBSAMPLE_NEG = 60          # negatives per recording, as the sweep used
MODELS = ["EEGNet", "ShallowFBCSPNet", "ATCNet", "SPARCNet"]
SEEDS = [1234, 3456, 5678, 7890, 9012]
LEAD_S = 120.0

def log(m): print(m, flush=True)
def mark(name): (OUT / "marks" / name).write_text("done")
def done(name): return (OUT / "marks" / name).exists()


# ================================================================= labels
def stage_labels():
    if not ANN.exists():
        sys.exit("%s not found -- run fix_labels.py rebuild first" % ANN)
    a = pd.read_csv(ANN)
    log("  %d seizures across %d subjects, median %.0f s"
        % (len(a), a.subject.nunique(), a.duration_s.median()))
    bad = a[(a.duration_s <= 0) | (a.duration_s > 3600)]
    if not bad.empty:
        sys.exit("implausible durations in the annotation file:\n%s" % bad)
    log("  every duration is between %.0f and %.0f s"
        % (a.duration_s.min(), a.duration_s.max()))
    mark("labels")


# ================================================================= shards
def stage_shards():
    """Re-extract the Siena windows with the corrected labels.

    The signal is unchanged, so only the labels move; the window grid, the
    preprocessing and the discard rule are exactly as before."""
    import importlib.util
    xc = None
    for c in (Path(r"D:\eeg_project\xcohort.py"), Path.cwd() / "xcohort.py"):
        if c.exists():
            sp = importlib.util.spec_from_file_location("xc", str(c))
            xc = importlib.util.module_from_spec(sp); sp.loader.exec_module(xc)
            break
    if xc is None:
        sys.exit("xcohort.py not found; its loaders are needed so that the "
                 "preprocessing matches the CHB-MIT shards exactly")

    ann = pd.read_csv(ANN)
    by_rec = {}
    for _, r in ann.iterrows():
        by_rec.setdefault(r.recording.lower(), []).append((r.start_s, r.end_s))

    for d in sorted(p for p in SIENA_DIR.iterdir() if p.is_dir()):
        out = OUT / "shards" / ("%s.npz" % d.name)
        if out.exists():
            continue
        Xs, ys, rs, os_ = [], [], [], []
        for f in sorted(d.glob("*.edf")):
            stem = f.stem.lower()
            sz = by_rec.get(stem, [])
            data, fs = xc.load_bipolar(f, "siena")
            if data is None:
                log("    %s: montage incomplete, skipped" % f.name); continue
            w = int(WIN_S * fs)
            mu = data.mean(1, keepdims=True); sd = data.std(1, keepdims=True) + 1e-12
            keep, lab = [], []
            for i in range(data.shape[1] // w):
                t0, t1 = i * WIN_S, (i + 1) * WIN_S
                ov = sum(max(0, min(t1, b) - max(t0, a)) for a, b in sz) / WIN_S
                if 0 < ov < POS_OVERLAP:
                    continue
                keep.append(i); lab.append(1 if ov >= POS_OVERLAP else 0)
            if not keep:
                continue
            X = np.stack([(data[:, i*w:(i+1)*w] - mu) / sd for i in keep])
            Xs.append(X.astype(np.float16)); ys.append(np.array(lab, np.int8))
            rs.append(np.array([f.stem] * len(keep)))
            os_.append(np.array(keep, np.int32))
            del data, X
        if not Xs:
            continue
        np.savez_compressed(out, X=np.concatenate(Xs), y=np.concatenate(ys),
                            rec=np.concatenate(rs), order=np.concatenate(os_))
        y = np.concatenate(ys)
        log("    %-6s %6d windows %4d positive (%.3f%%)"
            % (d.name, len(y), y.sum(), 100*y.mean()))
    tot = pos = 0
    for f in (OUT / "shards").glob("*.npz"):
        z = np.load(f); tot += len(z["y"]); pos += int(z["y"].sum())
    log("  Siena: %d windows, %d positive (%.3f%%)" % (tot, pos, 100*pos/max(tot,1)))
    log("  previously 126883 windows and 587 positive")
    mark("shards")


# ================================================================= features
# The feature vector must match D:\ablation\cache column for column, because
# cross-cohort training reads CHB-MIT from there and tests on what this
# writes. An earlier version of this stage used different Welch parameters,
# different spectral-model settings, and a different column order: bands
# grouped across channels rather than channels grouped across bands. The
# cross-patient figures were unaffected, being CHB-MIT on both sides, while
# the cross-cohort figures fell below chance. That is the signature of two
# feature spaces being compared, and it is why the settings below are copied
# from xcohort.py rather than rewritten.
#
#   119 spectral   per channel: 5 relative band powers, then the aperiodic
#                  exponent and its goodness of fit, interleaved channel by
#                  channel exactly as xcohort.feats() emits them
#    51 temporal   line length (17), Teager-Kaiser mean (17) and standard
#                  deviation (17), appended in the order ablation.py used

BANDS_ORDER = [(1, 4), (4, 8), (8, 13), (13, 30), (30, 40)]


def _spectral_one(args):
    """The 119 spectral features for one shard, matching xcohort.feats()."""
    import numpy as np
    from neurodsp.spectral import compute_spectrum
    from specparam import SpectralModel
    X, fs = args
    n, c, t = X.shape
    out = np.empty((n, c * 7), np.float32)
    sm = SpectralModel(aperiodic_mode="fixed", peak_width_limits=(0.5, 12),
                       max_n_peaks=6, min_peak_height=0.15, verbose=False)
    for i in range(n):
        bp, ap = [], []
        for ch in X[i]:
            fr, ps = compute_spectrum(ch, fs, method="welch",
                                      nperseg=int(fs), noverlap=int(fs // 2))
            tot = ps[(fr >= 1) & (fr <= 40)].sum() + 1e-20
            for lo, hi in BANDS_ORDER:
                bp.append(ps[(fr >= lo) & (fr < hi)].sum() / tot)
            try:
                sm.fit(fr, ps, [1, 40])
                r2 = float(sm.results.metrics.results["gof_rsquared"])
                a = np.atleast_1d(np.asarray(sm.get_params("aperiodic"), float)).ravel()
                ap += [float(a[-1]), r2]
            except Exception:
                ap += [np.nan, np.nan]
        out[i] = np.array(bp + ap, np.float32)
    return out


def _temporal(X):
    """Line length, Teager-Kaiser mean and standard deviation, per channel."""
    ll = np.abs(np.diff(X, axis=2)).sum(2)
    p = X[:, :, 1:-1] ** 2 - X[:, :, :-2] * X[:, :, 2:]
    return np.concatenate([ll, p.mean(2), p.std(2)], 1).astype(np.float32)


def _verify_layout():
    """Confirm the CHB-MIT cache has the layout this stage reproduces.

    Under xcohort's ordering the five relative band powers of a channel sum
    to one, because they are shares of the 1-40 Hz total. Under a
    band-grouped ordering they do not. This is a cheap and decisive check
    that the two feature spaces agree, and it is the check whose absence let
    the earlier mismatch through."""
    f = next(iter(sorted(CACHE_OLD.glob("chb*.npz"))), None)
    if f is None:
        log("  WARNING: no CHB-MIT cache to check against"); return
    X = np.load(f, allow_pickle=True)["X"][:200]
    per_ch = X[:, :85].reshape(len(X), 17, 5).sum(2)
    band_major = X[:, :85].reshape(len(X), 5, 17).sum(1)
    a, b = np.abs(per_ch - 1).mean(), np.abs(band_major - 1).mean()
    log("  layout check on %s: channel-grouped %.4f, band-grouped %.4f"
        % (f.stem, a, b))
    if a < b:
        log("  channel-grouped, as xcohort writes it; this stage matches")
    else:
        sys.exit("the CHB-MIT cache is band-grouped, which this stage does "
                 "not reproduce. Stopping rather than writing a second "
                 "feature space.")


def stage_feats():
    from multiprocessing import Pool
    _verify_layout()
    todo = [f for f in sorted((OUT / "shards").glob("*.npz"))
            if not (OUT / "cache" / f.name).exists()]
    log("  %d subjects to compute" % len(todo))
    for f in todo:
        z = np.load(f, allow_pickle=True)
        X = z["X"].astype(np.float32)
        n = len(X)
        chunks = [(X[i:i + 512], FS) for i in range(0, n, 512)]
        t0 = time.time()
        with Pool(min(8, len(chunks))) as pool:
            parts = pool.map(_spectral_one, chunks)
        S = np.vstack(parts)
        T = _temporal(X)
        F = np.hstack([S, T]).astype(np.float32)
        if F.shape[1] != 170:
            sys.exit("feature width %d, expected 170" % F.shape[1])
        np.savez_compressed(OUT / "cache" / f.name, X=F, y=z["y"],
                            rec=z["rec"], order=z["order"])
        bad = (~np.isfinite(F)).any(1).sum()
        log("    %-6s %6d x %d  (%d rows with a failed fit, %.1f min)"
            % (f.stem, F.shape[0], F.shape[1], bad, (time.time() - t0) / 60))
        del X, S, T, F
    mark("feats")


# ================================================================= data
def load_all():
    """CHB-MIT from the old cache, Siena from the new one."""
    X, y, sub, coh, rec, order = [], [], [], [], [], []
    for f in sorted(CACHE_OLD.glob("chb*.npz")):
        d = np.load(f, allow_pickle=True)
        if d["X"].size == 0: continue
        X.append(d["X"][:, :170]); y.append(d["y"])
        sub.append(np.full(len(d["y"]), f.stem)); coh.append(np.full(len(d["y"]), "chb"))
        rec.append(d["rec"].astype(str)); order.append(d["order"])
    for f in sorted((OUT / "cache").glob("*.npz")):
        d = np.load(f, allow_pickle=True)
        X.append(d["X"]); y.append(d["y"])
        sub.append(np.full(len(d["y"]), f.stem)); coh.append(np.full(len(d["y"]), "siena"))
        rec.append(d["rec"].astype(str)); order.append(d["order"])
    X = np.vstack(X); y = np.concatenate(y).astype(int)
    sub = np.concatenate(sub); coh = np.concatenate(coh)
    rec = np.concatenate(rec); order = np.concatenate(order)
    ok = np.isfinite(X).all(1)
    return X[ok], y[ok], sub[ok], coh[ok], rec[ok], order[ok]


# ================================================================= handcrafted
def stage_handcrafted():
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.metrics import roc_auc_score, average_precision_score
    from sklearn.model_selection import GroupKFold

    X, y, sub, coh, rec, order = load_all()
    patient = np.where(sub == "chb21", "chb01", sub)
    CHB = np.where(coh == "chb")[0]; SIE = np.where(coh == "siena")[0]
    log("  %d windows, %d positive; Siena %d positive of %d"
        % (len(y), y.sum(), y[SIE].sum(), len(SIE)))

    def lr(): return make_pipeline(StandardScaler(),
        LogisticRegression(max_iter=1000, class_weight="balanced"))
    def fit(cols, tr, te, clf=None, Xm=None):
        Xs = X if Xm is None else Xm
        Xtr, ytr = Xs[np.ix_(tr, cols)], y[tr]
        if len(ytr) > MAX_TRAIN:
            g = np.random.default_rng(SEED)
            p = np.where(ytr == 1)[0]; nn = np.where(ytr == 0)[0]
            nn = g.choice(nn, max(1, min(len(nn), MAX_TRAIN - len(p))), replace=False)
            k = np.concatenate([p, nn]); Xtr, ytr = Xtr[k], ytr[k]
        m = clf() if clf else lr(); m.fit(Xtr, ytr)
        return m.predict_proba(Xs[np.ix_(te, cols)])[:, 1]

    B, off = {}, 0
    for fam, w in (("bp", 85), ("ap", 34), ("ll", 17), ("tk", 34)):
        B[fam] = np.arange(off, off+w); off += w
    AB = np.concatenate([B["bp"], B["ap"]])
    ABC = np.arange(170)

    rows = []
    for name, cols in (("A", B["bp"]), ("B", B["ap"]),
                       ("C", np.concatenate([B["ll"], B["tk"]])),
                       ("AB", AB), ("ABC", ABC)):
        r = {"set": name}
        for tag, tr, te in (("S3fwd", CHB, SIE), ("S3rev", SIE, CHB)):
            s = fit(cols, tr, te)
            np.savez_compressed(OUT / "scores" / ("hand_%s_%s.npz" % (tag, name)),
                                score=s.astype(np.float32), label=y[te].astype(np.int8),
                                rec=rec[te], order=order[te].astype(np.int32))
            prev = float(y[te].mean()); ap = average_precision_score(y[te], s)
            r[tag] = float(roc_auc_score(y[te], s))
            r[tag + "_auprc"] = float(ap); r[tag + "_lift"] = float(ap/prev)
        a = []
        for tr_i, te_i in GroupKFold(5).split(CHB, y[CHB], patient[CHB]):
            trf, tef = CHB[tr_i], CHB[te_i]
            if len(np.unique(y[tef])) < 2: continue
            a.append(roc_auc_score(y[tef], fit(cols, trf, tef)))
        r["S2"] = float(np.mean(a))
        rows.append(r)
        log("  %-4s S2 %.3f  S3fwd %.3f  S3rev %.3f" % (name, r["S2"], r["S3fwd"], r["S3rev"]))

    # the stronger baseline
    blocks = [B["bp"][k*17:(k+1)*17] for k in range(5)] + \
             [B["ap"][:17], B["ll"], B["tk"][:17]]
    AGG = np.hstack([np.column_stack([v.mean(1), v.std(1), v.max(1), v.min(1),
                                      np.median(v, 1), np.percentile(v, 90, axis=1),
                                      v.max(1)-v.min(1)])
                     for v in (X[:, i] for i in blocks)]).astype(np.float32)
    XA = np.hstack([X, AGG])
    allc = np.arange(XA.shape[1])
    gb = lambda: HistGradientBoostingClassifier(max_iter=300, learning_rate=.1,
                                                class_weight="balanced", random_state=SEED)
    r = {"set": "ABC+agg, boosted"}
    for tag, tr, te in (("S3fwd", CHB, SIE), ("S3rev", SIE, CHB)):
        s = fit(allc, tr, te, gb, XA)
        r[tag] = float(roc_auc_score(y[te], s))
    rows.append(r)
    log("  %-16s S3fwd %.3f  S3rev %.3f  mean %.3f"
        % ("boosted", r["S3fwd"], r["S3rev"], (r["S3fwd"]+r["S3rev"])/2))
    pd.DataFrame(rows).to_csv(OUT / "handcrafted.csv", index=False)
    mark("handcrafted")


# ================================================================= learned
def stage_learned(causal=False):
    import torch, torch.nn as nn
    from torch.utils.data import TensorDataset, DataLoader
    from sklearn.metrics import roc_auc_score, average_precision_score
    import braindecode.models as M
    DEV = "cuda" if torch.cuda.is_available() else "cpu"
    tag_s = "causal" if causal else "whole"
    log("  device %s, normalisation %s" % (DEV, tag_s))

    def shards():
        d = {p.stem: p for p in CHB_SHARD.glob("chb*.npz")}
        d.update({p.stem: p for p in (OUT / "shards").glob("*.npz")})
        return d
    SH = shards()
    lead_n = int(LEAD_S / WIN_S)

    X, y, sub, coh = [], [], [], []
    for k, f in sorted(SH.items()):
        z = np.load(f, allow_pickle=True)
        if z["X"].size == 0: continue
        W = z["X"]
        if causal:
            key = "rec" if "rec" in z.files else "file"
            rc = z[key].astype(str); od = z["order"].astype(int)
            Wc = np.empty_like(W)
            for r in np.unique(rc):
                m = np.where(rc == r)[0]; m = m[np.argsort(od[m])]
                blk = W[m].astype(np.float32)
                ref = blk[:min(lead_n, len(blk))]
                Wc[m] = ((blk - ref.mean((0,2), keepdims=True)) /
                         (ref.std((0,2), keepdims=True) + 1e-6)).astype(W.dtype)
            W = Wc
        X.append(W); y.append(z["y"].astype(int))
        sub.append(np.full(len(z["y"]), k))
        coh.append(np.full(len(z["y"]), "chb" if k.lower().startswith("chb") else "siena"))
    X = np.concatenate(X); y = np.concatenate(y)
    sub = np.concatenate(sub); coh = np.concatenate(coh)
    CHB = np.where(coh == "chb")[0]; SIE = np.where(coh == "siena")[0]
    log("  %d windows, %d positive" % (len(y), y.sum()))

    def build(name):
        cls = getattr(M, name, None)
        for kw in (dict(n_chans=17, n_outputs=2, n_times=1024, sfreq=FS),
                   dict(n_chans=17, n_outputs=2, n_times=1024)):
            try:
                m = cls(**kw)
                with torch.no_grad():
                    o = m(torch.zeros(2, 17, 1024))
                return nn.Sequential(m, nn.AdaptiveAvgPool1d(1), nn.Flatten()) \
                       if o.ndim == 3 else m
            except Exception:
                continue
        return None

    rows = []
    seeds = SEEDS if not causal else SEEDS[:1]
    for name in MODELS:
        for seed in seeds:
            for tag, tr, te in (("S3fwd", CHB, SIE), ("S3rev", SIE, CHB)):
                rid = "%s_%s_s%d_%s" % (name, tag, seed, tag_s)
                f = OUT / "scores" / (rid + ".npz")
                if f.exists(): continue
                torch.manual_seed(seed); np.random.seed(seed)
                g = np.random.default_rng(seed)
                pos = tr[y[tr] == 1]; neg = tr[y[tr] == 0]
                nsub = min(len(neg), SUBSAMPLE_NEG * len(np.unique(sub[tr])))
                tr2 = np.concatenate([pos, g.choice(neg, nsub, replace=False)])
                perm = g.permutation(len(tr2)); nval = max(1, int(len(tr2)*VAL_FRAC))
                val, fitx = tr2[perm[:nval]], tr2[perm[nval:]]
                model = build(name)
                if model is None: break
                model = model.to(DEV)
                w = torch.tensor([1.0, max(1.0, (y[fitx]==0).sum()/max((y[fitx]==1).sum(),1))],
                                 dtype=torch.float32, device=DEV)
                opt = torch.optim.Adam(model.parameters(), lr=LR)
                lf = nn.CrossEntropyLoss(weight=w)
                dl = DataLoader(TensorDataset(
                    torch.from_numpy(X[fitx].astype(np.float32)),
                    torch.from_numpy(y[fitx]).long()), batch_size=BATCH, shuffle=True)
                Xv = torch.from_numpy(X[val].astype(np.float32))
                best, bstate, pat = -1, None, 0
                for ep in range(EPOCHS):
                    model.train()
                    for xb, yb in dl:
                        opt.zero_grad(); lf(model(xb.to(DEV)), yb.to(DEV)).backward(); opt.step()
                    model.eval()
                    with torch.no_grad():
                        sv = np.concatenate([torch.softmax(
                            model(Xv[i:i+512].to(DEV)).float(),1)[:,1].cpu().numpy()
                            for i in range(0, len(Xv), 512)])
                    a = roc_auc_score(y[val], sv) if len(np.unique(y[val]))>1 else .5
                    if a > best:
                        best, bstate, pat = a, {k: v.detach().cpu().clone()
                                                for k,v in model.state_dict().items()}, 0
                    else:
                        pat += 1
                        if pat >= 3: break
                if bstate: model.load_state_dict(bstate)
                model.eval()
                with torch.no_grad():
                    s = np.concatenate([torch.softmax(model(
                        torch.from_numpy(X[te[i:i+512]].astype(np.float32)).to(DEV)).float(),
                        1)[:,1].cpu().numpy() for i in range(0, len(te), 512)])
                del model
                if DEV == "cuda": torch.cuda.empty_cache()
                np.savez_compressed(f, score=s.astype(np.float32),
                                    label=y[te].astype(np.int8), subject=sub[te])
                prev = float(y[te].mean()); apv = average_precision_score(y[te], s)
                rows.append(dict(model=name, setting=tag, seed=seed, norm=tag_s,
                                 auroc=float(roc_auc_score(y[te], s)),
                                 auprc=float(apv), lift=float(apv/prev), epochs=ep+1))
                log("  %-34s AUROC %.3f (%d ep)" % (rid, rows[-1]["auroc"], ep+1))
    if rows:
        pd.DataFrame(rows).to_csv(OUT / ("learned_%s.csv" % tag_s), mode="a",
            header=not (OUT / ("learned_%s.csv" % tag_s)).exists(), index=False)
    del X
    mark("learned" if not causal else "causal")


# ================================================================= report
def stage_report():
    need = ["labels", "shards", "feats", "handcrafted", "learned"]
    missing = [n for n in need if not done(n)]
    if missing:
        sys.exit("these stages have not run: %s" % missing)
    log("#" * 66)
    log("CORRECTED SIENA LABELS: WHAT CHANGED")
    log("#" * 66)
    h = pd.read_csv(OUT / "handcrafted.csv")
    log("\nhandcrafted, cross-cohort:")
    log(h.to_string(index=False))
    log("\n  before the correction: ABC S3fwd 0.789  S3rev 0.787  S2 0.801")
    for f, lab in ((OUT / "learned_whole.csv", "whole-recording"),
                   (OUT / "learned_causal.csv", "causal")):
        if f.exists():
            d = pd.read_csv(f)
            log("\nlearned, %s normalisation:" % lab)
            log(d.groupby(["model", "setting"]).auroc.mean().round(4).to_string())
            log("  pooled S3 %.4f" % d.auroc.mean())
    log("\n  before the correction: learned S3 0.843 (fwd 0.828, rev 0.859)")
    log("\nThe within-patient and cross-patient figures are unaffected, being")
    log("CHB-MIT only, and were not rerun.")
    mark("report")


STAGES = [("labels", stage_labels), ("shards", stage_shards),
          ("feats", stage_feats), ("handcrafted", stage_handcrafted),
          ("learned", lambda: stage_learned(False)),
          ("causal", lambda: stage_learned(True)), ("report", stage_report)]

if __name__ == "__main__":
    args = sys.argv[1:]
    names = [n for n, _ in STAGES]
    if args and args[0] == "--from":
        i = names.index(args[1]); run = names[i:]
    elif args:
        run = [a for a in args if a in names]
    else:
        run = names
    t0 = time.time()
    for n, fn in STAGES:
        if n not in run:
            continue
        if done(n) and n != "report":
            log("\n=== %s: already done, skipping ===" % n); continue
        log("\n" + "=" * 66)
        log("%s  (%.0f min elapsed)" % (n.upper(), (time.time()-t0)/60))
        log("=" * 66)
        fn()
    log("\n%.1f min | %s" % ((time.time()-t0)/60, OUT))
