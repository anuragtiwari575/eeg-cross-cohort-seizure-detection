"""
=============================================================================
CHECK WHAT SURVIVED AND WHAT IS LEFT TO DO
=============================================================================
    python -u resume.py            report only, changes nothing
    python -u resume.py --repair   also delete files that will not open

Run this after an interruption, before rerun_siena.py.

WHY IT IS NEEDED

rerun_siena.py resumes by skipping any output file that already exists. That
is the right rule when a file is either absent or complete, and the wrong
one when the machine stopped while a file was being written: a truncated
.npz exists, so the stage skips it, and the run continues on data that
cannot be read. The failure surfaces much later, in a stage that had nothing
to do with it.

This opens every artefact, confirms it loads and that its arrays agree in
length, and lists what is missing. With --repair it deletes the ones that
fail, so the next run rebuilds exactly those.

It also checks the stage markers against the artefacts, because a marker
written before an interruption would otherwise skip a stage that is only
partly done.
=============================================================================
"""
from pathlib import Path
import sys, shutil, warnings
warnings.filterwarnings("ignore")
import numpy as np

OUT = Path(r"D:\siena_v2")
SIENA_DIR = Path(r"D:\CPU-Intel 7\C_Drive\archive\siena-scalp-eeg-database-1.0.0")
MODELS = ["EEGNet", "ShallowFBCSPNet", "ATCNet", "SPARCNet"]
SEEDS = [1234, 3456, 5678, 7890, 9012]

REPAIR = "--repair" in sys.argv
def log(m): print(m, flush=True)


def readable(f, keys, same_len=True):
    """Open the file and check the arrays are there and consistent."""
    try:
        z = np.load(f, allow_pickle=True)
        for k in keys:
            if k not in z.files:
                return "missing array '%s'" % k
        if same_len:
            n = {len(z[k]) for k in keys}
            if len(n) != 1:
                return "arrays of different lengths %s" % sorted(n)
        _ = z[keys[0]][:1]          # force a read of the compressed data
        return None
    except Exception as e:
        return "%s: %s" % (type(e).__name__, str(e)[:60])


def check(folder, keys, expected=None, label=""):
    bad, good = [], []
    for f in sorted(folder.glob("*.npz")):
        err = readable(f, keys)
        (bad if err else good).append((f, err))
    log("\n%s  (%s)" % (label, folder))
    log("  %d readable" % len(good))
    for f, err in bad:
        log("  CORRUPT  %-28s %s" % (f.name, err))
        if REPAIR:
            f.unlink(); log("           deleted")
    if expected is not None:
        have = {f.stem for f, _ in good}
        miss = sorted(set(expected) - have)
        if miss:
            log("  missing %d: %s" % (len(miss), " ".join(miss[:12]) +
                                      (" ..." if len(miss) > 12 else "")))
        else:
            log("  complete")
    return len(good), len(bad)


subjects = sorted(p.name for p in SIENA_DIR.iterdir() if p.is_dir()) \
           if SIENA_DIR.exists() else None

log("=" * 66)
log("ARTEFACTS")
log("=" * 66)
ns, bs = check(OUT / "shards", ["X", "y", "rec", "order"], subjects, "shards")
nf, bf = check(OUT / "cache",  ["X", "y", "rec", "order"], subjects, "features")

exp_scores = []
for m in MODELS:
    for s in SEEDS:
        for d in ("S3fwd", "S3rev"):
            exp_scores.append("%s_%s_s%d_whole" % (m, d, s))
for m in MODELS:
    for d in ("S3fwd", "S3rev"):
        exp_scores.append("%s_%s_s%d_causal" % (m, d, SEEDS[0]))
for n in ("A", "B", "C", "AB", "ABC"):
    for d in ("S3fwd", "S3rev"):
        exp_scores.append("hand_%s_%s" % (d, n))
nsc, bsc = check(OUT / "scores", ["score", "label"], exp_scores, "scores")

log("\n" + "=" * 66)
log("STAGE MARKERS AGAINST ARTEFACTS")
log("=" * 66)
marks = OUT / "marks"
state = {
    "labels":      (Path(r"D:\siena_fixed\annotations.csv").exists(), "annotations.csv"),
    "shards":      (subjects is not None and ns == len(subjects), "%d/%s shards" % (ns, len(subjects or []))),
    "feats":       (subjects is not None and nf == len(subjects), "%d/%s feature files" % (nf, len(subjects or []))),
    "handcrafted": ((OUT / "handcrafted.csv").exists(), "handcrafted.csv"),
    "learned":     (len([f for f in (OUT/"scores").glob("*_whole.npz")]) >= 40,
                    "%d/40 whole-normalisation runs" % len(list((OUT/"scores").glob("*_whole.npz")))),
    "causal":      (len([f for f in (OUT/"scores").glob("*_causal.npz")]) >= 8,
                    "%d/8 causal runs" % len(list((OUT/"scores").glob("*_causal.npz")))),
}
stale = []
for name, (ok, why) in state.items():
    m = marks / name
    if m.exists() and not ok:
        stale.append(name)
        log("  %-12s marker present but %s  <-- STALE" % (name, why))
        if REPAIR:
            m.unlink(); log("               marker removed")
    elif m.exists():
        log("  %-12s done        (%s)" % (name, why))
    elif ok:
        log("  %-12s complete but not marked (%s)" % (name, why))
        if REPAIR:
            m.write_text("done"); log("               marker written")
    else:
        log("  %-12s to do       (%s)" % (name, why))

log("\n" + "=" * 66)
if not REPAIR and (bs or bf or bsc or stale):
    log("Run again with --repair to delete the corrupt files and clear the")
    log("stale markers, then continue with rerun_siena.py.")
elif REPAIR:
    log("Repaired. Now run:")
    log("    python -u rerun_siena.py")
    log("It will skip what is complete and rebuild only what was removed.")
else:
    log("Everything present and readable. Continue with:")
    log("    python -u rerun_siena.py")
log("=" * 66)
